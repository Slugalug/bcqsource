<!DOCTYPE html>
<html lang="en">
<head>
    
<link href="/1723204578/bootflat/css/fontawesome-pro-6.5.2-web/css/all.min.css" rel="stylesheet" type="text/css">
<link href="/1723204578/bootflat/css/fontawesome-pro-6.5.2-web/css/v4-shims.min.css" rel="stylesheet" type="text/css">
	<link rel="icon" type="image/x-icon" href="/favicon.ico">
	<title>Box Car Quilts Create Account </title>
	<meta name="description" content="">
	
	<link rel="canonical" href="https://www.boxcarquilts.com/c/account/login.php">
	

	<!-- BOOTSTRAP START -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge"><script type="text/javascript">(window.NREUM||(NREUM={})).init={privacy:{cookies_enabled:true},ajax:{deny_list:["bam.nr-data.net"]},distributed_tracing:{enabled:true}};(window.NREUM||(NREUM={})).loader_config={agentID:"7339834",accountID:"732355",trustKey:"732355",licenseKey:"d60c52fc57",applicationID:"7339757"};;/*! For license information please see nr-loader-rum-1.293.0.min.js.LICENSE.txt */
(()=>{var e,t,r={122:(e,t,r)=>{"use strict";r.d(t,{a:()=>i});var n=r(944);function i(e,t){try{if(!e||"object"!=typeof e)return(0,n.R)(3);if(!t||"object"!=typeof t)return(0,n.R)(4);const r=Object.create(Object.getPrototypeOf(t),Object.getOwnPropertyDescriptors(t)),a=0===Object.keys(r).length?e:r;for(let o in a)if(void 0!==e[o])try{if(null===e[o]){r[o]=null;continue}Array.isArray(e[o])&&Array.isArray(t[o])?r[o]=Array.from(new Set([...e[o],...t[o]])):"object"==typeof e[o]&&"object"==typeof t[o]?r[o]=i(e[o],t[o]):r[o]=e[o]}catch(e){r[o]||(0,n.R)(1,e)}return r}catch(e){(0,n.R)(2,e)}}},555:(e,t,r)=>{"use strict";r.d(t,{D:()=>s,f:()=>o});var n=r(384),i=r(122);const a={beacon:n.NT.beacon,errorBeacon:n.NT.errorBeacon,licenseKey:void 0,applicationID:void 0,sa:void 0,queueTime:void 0,applicationTime:void 0,ttGuid:void 0,user:void 0,account:void 0,product:void 0,extra:void 0,jsAttributes:{},userAttributes:void 0,atts:void 0,transactionName:void 0,tNamePlain:void 0};function o(e){try{return!!e.licenseKey&&!!e.errorBeacon&&!!e.applicationID}catch(e){return!1}}const s=e=>(0,i.a)(e,a)},324:(e,t,r)=>{"use strict";r.d(t,{F3:()=>i,Xs:()=>a,xv:()=>n});const n="1.293.0",i="PROD",a="CDN"},154:(e,t,r)=>{"use strict";r.d(t,{OF:()=>c,RI:()=>i,WN:()=>d,bv:()=>a,gm:()=>o,mw:()=>s,sb:()=>u});var n=r(863);const i="undefined"!=typeof window&&!!window.document,a="undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self.navigator instanceof WorkerNavigator||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis.navigator instanceof WorkerNavigator),o=i?window:"undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis),s=Boolean("hidden"===o?.document?.visibilityState),c=/iPad|iPhone|iPod/.test(o.navigator?.userAgent),u=c&&"undefined"==typeof SharedWorker,d=((()=>{const e=o.navigator?.userAgent?.match(/Firefox[/\s](\d+\.\d+)/);Array.isArray(e)&&e.length>=2&&e[1]})(),Date.now()-(0,n.t)())},241:(e,t,r)=>{"use strict";r.d(t,{W:()=>a});var n=r(154);const i="newrelic";function a(e={}){try{n.gm.dispatchEvent(new CustomEvent(i,{detail:e}))}catch(e){}}},687:(e,t,r)=>{"use strict";r.d(t,{Ak:()=>u,Ze:()=>f,x3:()=>d});var n=r(241),i=r(836),a=r(606),o=r(860),s=r(646);const c={};function u(e,t){const r={staged:!1,priority:o.P3[t]||0};l(e),c[e].get(t)||c[e].set(t,r)}function d(e,t){e&&c[e]&&(c[e].get(t)&&c[e].delete(t),p(e,t,!1),c[e].size&&g(e))}function l(e){if(!e)throw new Error("agentIdentifier required");c[e]||(c[e]=new Map)}function f(e="",t="feature",r=!1){if(l(e),!e||!c[e].get(t)||r)return p(e,t);c[e].get(t).staged=!0,g(e)}function g(e){const t=Array.from(c[e]);t.every((([e,t])=>t.staged))&&(t.sort(((e,t)=>e[1].priority-t[1].priority)),t.forEach((([t])=>{c[e].delete(t),p(e,t)})))}function p(e,t,r=!0){const o=e?i.ee.get(e):i.ee,c=a.i.handlers;if(!o.aborted&&o.backlog&&c){if((0,n.W)({agentIdentifier:e,type:"lifecycle",name:"drain",feature:t}),r){const e=o.backlog[t],r=c[t];if(r){for(let t=0;e&&t<e.length;++t)m(e[t],r);Object.entries(r).forEach((([e,t])=>{Object.values(t||{}).forEach((t=>{t[0]?.on&&t[0]?.context()instanceof s.y&&t[0].on(e,t[1])}))}))}}o.isolatedBacklog||delete c[t],o.backlog[t]=null,o.emit("drain-"+t,[])}}function m(e,t){var r=e[1];Object.values(t[r]||{}).forEach((t=>{var r=e[0];if(t[0]===r){var n=t[1],i=e[3],a=e[2];n.apply(i,a)}}))}},836:(e,t,r)=>{"use strict";r.d(t,{P:()=>s,ee:()=>c});var n=r(384),i=r(990),a=r(646),o=r(607);const s="nr@context:".concat(o.W),c=function e(t,r){var n={},o={},d={},l=!1;try{l=16===r.length&&u.initializedAgents?.[r]?.runtime.isolatedBacklog}catch(e){}var f={on:p,addEventListener:p,removeEventListener:function(e,t){var r=n[e];if(!r)return;for(var i=0;i<r.length;i++)r[i]===t&&r.splice(i,1)},emit:function(e,r,n,i,a){!1!==a&&(a=!0);if(c.aborted&&!i)return;t&&a&&t.emit(e,r,n);for(var s=g(n),u=m(e),d=u.length,l=0;l<d;l++)u[l].apply(s,r);var p=v()[o[e]];p&&p.push([f,e,r,s]);return s},get:h,listeners:m,context:g,buffer:function(e,t){const r=v();if(t=t||"feature",f.aborted)return;Object.entries(e||{}).forEach((([e,n])=>{o[n]=t,t in r||(r[t]=[])}))},abort:function(){f._aborted=!0,Object.keys(f.backlog).forEach((e=>{delete f.backlog[e]}))},isBuffering:function(e){return!!v()[o[e]]},debugId:r,backlog:l?{}:t&&"object"==typeof t.backlog?t.backlog:{},isolatedBacklog:l};return Object.defineProperty(f,"aborted",{get:()=>{let e=f._aborted||!1;return e||(t&&(e=t.aborted),e)}}),f;function g(e){return e&&e instanceof a.y?e:e?(0,i.I)(e,s,(()=>new a.y(s))):new a.y(s)}function p(e,t){n[e]=m(e).concat(t)}function m(e){return n[e]||[]}function h(t){return d[t]=d[t]||e(f,t)}function v(){return f.backlog}}(void 0,"globalEE"),u=(0,n.Zm)();u.ee||(u.ee=c)},646:(e,t,r)=>{"use strict";r.d(t,{y:()=>n});class n{constructor(e){this.contextId=e}}},908:(e,t,r)=>{"use strict";r.d(t,{d:()=>n,p:()=>i});var n=r(836).ee.get("handle");function i(e,t,r,i,a){a?(a.buffer([e],i),a.emit(e,t,r)):(n.buffer([e],i),n.emit(e,t,r))}},606:(e,t,r)=>{"use strict";r.d(t,{i:()=>a});var n=r(908);a.on=o;var i=a.handlers={};function a(e,t,r,a){o(a||n.d,i,e,t,r)}function o(e,t,r,i,a){a||(a="feature"),e||(e=n.d);var o=t[a]=t[a]||{};(o[r]=o[r]||[]).push([e,i])}},878:(e,t,r)=>{"use strict";function n(e,t){return{capture:e,passive:!1,signal:t}}function i(e,t,r=!1,i){window.addEventListener(e,t,n(r,i))}function a(e,t,r=!1,i){document.addEventListener(e,t,n(r,i))}r.d(t,{DD:()=>a,jT:()=>n,sp:()=>i})},607:(e,t,r)=>{"use strict";r.d(t,{W:()=>n});const n=(0,r(566).bz)()},566:(e,t,r)=>{"use strict";r.d(t,{LA:()=>s,bz:()=>o});var n=r(154);const i="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";function a(e,t){return e?15&e[t]:16*Math.random()|0}function o(){const e=n.gm?.crypto||n.gm?.msCrypto;let t,r=0;return e&&e.getRandomValues&&(t=e.getRandomValues(new Uint8Array(30))),i.split("").map((e=>"x"===e?a(t,r++).toString(16):"y"===e?(3&a()|8).toString(16):e)).join("")}function s(e){const t=n.gm?.crypto||n.gm?.msCrypto;let r,i=0;t&&t.getRandomValues&&(r=t.getRandomValues(new Uint8Array(e)));const o=[];for(var s=0;s<e;s++)o.push(a(r,i++).toString(16));return o.join("")}},614:(e,t,r)=>{"use strict";r.d(t,{BB:()=>o,H3:()=>n,g:()=>u,iL:()=>c,tS:()=>s,uh:()=>i,wk:()=>a});const n="NRBA",i="SESSION",a=144e5,o=18e5,s={STARTED:"session-started",PAUSE:"session-pause",RESET:"session-reset",RESUME:"session-resume",UPDATE:"session-update"},c={SAME_TAB:"same-tab",CROSS_TAB:"cross-tab"},u={OFF:0,FULL:1,ERROR:2}},863:(e,t,r)=>{"use strict";function n(){return Math.floor(performance.now())}r.d(t,{t:()=>n})},944:(e,t,r)=>{"use strict";r.d(t,{R:()=>i});var n=r(241);function i(e,t){"function"==typeof console.debug&&(console.debug("New Relic Warning: https://github.com/newrelic/newrelic-browser-agent/blob/main/docs/warning-codes.md#".concat(e),t),(0,n.W)({agentIdentifier:null,drained:null,type:"data",name:"warn",feature:"warn",data:{code:e,secondary:t}}))}},701:(e,t,r)=>{"use strict";r.d(t,{B:()=>a,t:()=>o});var n=r(241);const i=new Set,a={};function o(e,t){const r=t.agentIdentifier;a[r]??={},e&&"object"==typeof e&&(i.has(r)||(t.ee.emit("rumresp",[e]),a[r]=e,i.add(r),(0,n.W)({agentIdentifier:r,loaded:!0,drained:!0,type:"lifecycle",name:"load",feature:void 0,data:e})))}},990:(e,t,r)=>{"use strict";r.d(t,{I:()=>i});var n=Object.prototype.hasOwnProperty;function i(e,t,r){if(n.call(e,t))return e[t];var i=r();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:i,writable:!0,enumerable:!1}),i}catch(e){}return e[t]=i,i}},389:(e,t,r)=>{"use strict";function n(e,t=500,r={}){const n=r?.leading||!1;let i;return(...r)=>{n&&void 0===i&&(e.apply(this,r),i=setTimeout((()=>{i=clearTimeout(i)}),t)),n||(clearTimeout(i),i=setTimeout((()=>{e.apply(this,r)}),t))}}function i(e){let t=!1;return(...r)=>{t||(t=!0,e.apply(this,r))}}r.d(t,{J:()=>i,s:()=>n})},289:(e,t,r)=>{"use strict";r.d(t,{GG:()=>a,Qr:()=>s,sB:()=>o});var n=r(878);function i(){return"undefined"==typeof document||"complete"===document.readyState}function a(e,t){if(i())return e();(0,n.sp)("load",e,t)}function o(e){if(i())return e();(0,n.DD)("DOMContentLoaded",e)}function s(e){if(i())return e();(0,n.sp)("popstate",e)}},384:(e,t,r)=>{"use strict";r.d(t,{NT:()=>a,US:()=>u,Zm:()=>o,bQ:()=>c,dV:()=>s,pV:()=>d});var n=r(154),i=r(863);const a={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net"};function o(){return n.gm.NREUM||(n.gm.NREUM={}),void 0===n.gm.newrelic&&(n.gm.newrelic=n.gm.NREUM),n.gm.NREUM}function s(){let e=o();return e.o||(e.o={ST:n.gm.setTimeout,SI:n.gm.setImmediate,CT:n.gm.clearTimeout,XHR:n.gm.XMLHttpRequest,REQ:n.gm.Request,EV:n.gm.Event,PR:n.gm.Promise,MO:n.gm.MutationObserver,FETCH:n.gm.fetch,WS:n.gm.WebSocket}),e}function c(e,t){let r=o();r.initializedAgents??={},t.initializedAt={ms:(0,i.t)(),date:new Date},r.initializedAgents[e]=t}function u(e,t){o()[e]=t}function d(){return function(){let e=o();const t=e.info||{};e.info={beacon:a.beacon,errorBeacon:a.errorBeacon,...t}}(),function(){let e=o();const t=e.init||{};e.init={...t}}(),s(),function(){let e=o();const t=e.loader_config||{};e.loader_config={...t}}(),o()}},843:(e,t,r)=>{"use strict";r.d(t,{u:()=>i});var n=r(878);function i(e,t=!1,r,i){(0,n.DD)("visibilitychange",(function(){if(t)return void("hidden"===document.visibilityState&&e());e(document.visibilityState)}),r,i)}},773:(e,t,r)=>{"use strict";r.d(t,{z_:()=>a,XG:()=>s,TZ:()=>n,rs:()=>i,xV:()=>o});r(154),r(566),r(384);const n=r(860).K7.metrics,i="sm",a="cm",o="storeSupportabilityMetrics",s="storeEventMetrics"},630:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K7.pageViewEvent},782:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K7.pageViewTiming},234:(e,t,r)=>{"use strict";r.d(t,{W:()=>a});var n=r(836),i=r(687);class a{constructor(e,t){this.agentIdentifier=e,this.ee=n.ee.get(e),this.featureName=t,this.blocked=!1}deregisterDrain(){(0,i.x3)(this.agentIdentifier,this.featureName)}}},741:(e,t,r)=>{"use strict";r.d(t,{W:()=>a});var n=r(944),i=r(261);class a{#e(e,...t){if(this[e]!==a.prototype[e])return this[e](...t);(0,n.R)(35,e)}addPageAction(e,t){return this.#e(i.hG,e,t)}register(e){return this.#e(i.eY,e)}recordCustomEvent(e,t){return this.#e(i.fF,e,t)}setPageViewName(e,t){return this.#e(i.Fw,e,t)}setCustomAttribute(e,t,r){return this.#e(i.cD,e,t,r)}noticeError(e,t){return this.#e(i.o5,e,t)}setUserId(e){return this.#e(i.Dl,e)}setApplicationVersion(e){return this.#e(i.nb,e)}setErrorHandler(e){return this.#e(i.bt,e)}addRelease(e,t){return this.#e(i.k6,e,t)}log(e,t){return this.#e(i.$9,e,t)}start(){return this.#e(i.d3)}finished(e){return this.#e(i.BL,e)}recordReplay(){return this.#e(i.CH)}pauseReplay(){return this.#e(i.Tb)}addToTrace(e){return this.#e(i.U2,e)}setCurrentRouteName(e){return this.#e(i.PA,e)}interaction(){return this.#e(i.dT)}wrapLogger(e,t,r){return this.#e(i.Wb,e,t,r)}measure(e,t){return this.#e(i.V1,e,t)}}},261:(e,t,r)=>{"use strict";r.d(t,{$9:()=>u,BL:()=>s,CH:()=>g,Dl:()=>_,Fw:()=>y,PA:()=>h,Pl:()=>n,Tb:()=>l,U2:()=>a,V1:()=>k,Wb:()=>x,bt:()=>b,cD:()=>v,d3:()=>w,dT:()=>c,eY:()=>p,fF:()=>f,hG:()=>i,k6:()=>o,nb:()=>m,o5:()=>d});const n="api-",i="addPageAction",a="addToTrace",o="addRelease",s="finished",c="interaction",u="log",d="noticeError",l="pauseReplay",f="recordCustomEvent",g="recordReplay",p="register",m="setApplicationVersion",h="setCurrentRouteName",v="setCustomAttribute",b="setErrorHandler",y="setPageViewName",_="setUserId",w="start",x="wrapLogger",k="measure"},163:(e,t,r)=>{"use strict";r.d(t,{j:()=>E});var n=r(384),i=r(741);var a=r(555);r(860).K7.genericEvents;const o="experimental.marks",s="experimental.measures",c="experimental.resources",u=e=>{if(!e||"string"!=typeof e)return!1;try{document.createDocumentFragment().querySelector(e)}catch{return!1}return!0};var d=r(614),l=r(944),f=r(122);const g="[data-nr-mask]",p=e=>(0,f.a)(e,(()=>{const e={feature_flags:[],experimental:{marks:!1,measures:!1,resources:!1},mask_selector:"*",block_selector:"[data-nr-block]",mask_input_options:{color:!1,date:!1,"datetime-local":!1,email:!1,month:!1,number:!1,range:!1,search:!1,tel:!1,text:!1,time:!1,url:!1,week:!1,textarea:!1,select:!1,password:!0}};return{ajax:{deny_list:void 0,block_internal:!0,enabled:!0,autoStart:!0},api:{allow_registered_children:!0,duplicate_registered_data:!1},distributed_tracing:{enabled:void 0,exclude_newrelic_header:void 0,cors_use_newrelic_header:void 0,cors_use_tracecontext_headers:void 0,allowed_origins:void 0},get feature_flags(){return e.feature_flags},set feature_flags(t){e.feature_flags=t},generic_events:{enabled:!0,autoStart:!0},harvest:{interval:30},jserrors:{enabled:!0,autoStart:!0},logging:{enabled:!0,autoStart:!0},metrics:{enabled:!0,autoStart:!0},obfuscate:void 0,page_action:{enabled:!0},page_view_event:{enabled:!0,autoStart:!0},page_view_timing:{enabled:!0,autoStart:!0},performance:{get capture_marks(){return e.feature_flags.includes(o)||e.experimental.marks},set capture_marks(t){e.experimental.marks=t},get capture_measures(){return e.feature_flags.includes(s)||e.experimental.measures},set capture_measures(t){e.experimental.measures=t},capture_detail:!0,resources:{get enabled(){return e.feature_flags.includes(c)||e.experimental.resources},set enabled(t){e.experimental.resources=t},asset_types:[],first_party_domains:[],ignore_newrelic:!0}},privacy:{cookies_enabled:!0},proxy:{assets:void 0,beacon:void 0},session:{expiresMs:d.wk,inactiveMs:d.BB},session_replay:{autoStart:!0,enabled:!1,preload:!1,sampling_rate:10,error_sampling_rate:100,collect_fonts:!1,inline_images:!1,fix_stylesheets:!0,mask_all_inputs:!0,get mask_text_selector(){return e.mask_selector},set mask_text_selector(t){u(t)?e.mask_selector="".concat(t,",").concat(g):""===t||null===t?e.mask_selector=g:(0,l.R)(5,t)},get block_class(){return"nr-block"},get ignore_class(){return"nr-ignore"},get mask_text_class(){return"nr-mask"},get block_selector(){return e.block_selector},set block_selector(t){u(t)?e.block_selector+=",".concat(t):""!==t&&(0,l.R)(6,t)},get mask_input_options(){return e.mask_input_options},set mask_input_options(t){t&&"object"==typeof t?e.mask_input_options={...t,password:!0}:(0,l.R)(7,t)}},session_trace:{enabled:!0,autoStart:!0},soft_navigations:{enabled:!0,autoStart:!0},spa:{enabled:!0,autoStart:!0},ssl:void 0,user_actions:{enabled:!0,elementAttributes:["id","className","tagName","type"]}}})());var m=r(154),h=r(324);let v=0;const b={buildEnv:h.F3,distMethod:h.Xs,version:h.xv,originTime:m.WN},y={appMetadata:{},customTransaction:void 0,denyList:void 0,disabled:!1,entityManager:void 0,harvester:void 0,isolatedBacklog:!1,isRecording:!1,loaderType:void 0,maxBytes:3e4,obfuscator:void 0,onerror:void 0,ptid:void 0,releaseIds:{},session:void 0,timeKeeper:void 0,get harvestCount(){return++v}},_=e=>{const t=(0,f.a)(e,y),r=Object.keys(b).reduce(((e,t)=>(e[t]={value:b[t],writable:!1,configurable:!0,enumerable:!0},e)),{});return Object.defineProperties(t,r)};var w=r(701);const x=e=>{const t=e.startsWith("http");e+="/",r.p=t?e:"https://"+e};var k=r(836),A=r(241);const S={accountID:void 0,trustKey:void 0,agentID:void 0,licenseKey:void 0,applicationID:void 0,xpid:void 0},T=e=>(0,f.a)(e,S),R=new Set;function E(e,t={},r,o){let{init:s,info:c,loader_config:u,runtime:d={},exposed:l=!0}=t;if(!c){const e=(0,n.pV)();s=e.init,c=e.info,u=e.loader_config}e.init=p(s||{}),e.loader_config=T(u||{}),c.jsAttributes??={},m.bv&&(c.jsAttributes.isWorker=!0),e.info=(0,a.D)(c);const f=e.init,g=[c.beacon,c.errorBeacon];R.has(e.agentIdentifier)||(f.proxy.assets&&(x(f.proxy.assets),g.push(f.proxy.assets)),f.proxy.beacon&&g.push(f.proxy.beacon),function(e){const t=(0,n.pV)();Object.getOwnPropertyNames(i.W.prototype).forEach((r=>{const n=i.W.prototype[r];if("function"!=typeof n||"constructor"===n)return;let a=t[r];e[r]&&!1!==e.exposed&&"micro-agent"!==e.runtime?.loaderType&&(t[r]=(...t)=>{const n=e[r](...t);return a?a(...t):n})}))}(e),(0,n.US)("activatedFeatures",w.B),e.runSoftNavOverSpa&&=!0===f.soft_navigations.enabled&&f.feature_flags.includes("soft_nav")),d.denyList=[...f.ajax.deny_list||[],...f.ajax.block_internal?g:[]],d.ptid=e.agentIdentifier,d.loaderType=r,e.runtime=_(d),R.has(e.agentIdentifier)||(e.ee=k.ee.get(e.agentIdentifier),e.exposed=l,(0,A.W)({agentIdentifier:e.agentIdentifier,drained:!!w.B?.[e.agentIdentifier],type:"lifecycle",name:"initialize",feature:void 0,data:e.config})),R.add(e.agentIdentifier)}},374:(e,t,r)=>{r.nc=(()=>{try{return document?.currentScript?.nonce}catch(e){}return""})()},860:(e,t,r)=>{"use strict";r.d(t,{$J:()=>d,K7:()=>c,P3:()=>u,XX:()=>i,Yy:()=>s,df:()=>a,qY:()=>n,v4:()=>o});const n="events",i="jserrors",a="browser/blobs",o="rum",s="browser/logs",c={ajax:"ajax",genericEvents:"generic_events",jserrors:i,logging:"logging",metrics:"metrics",pageAction:"page_action",pageViewEvent:"page_view_event",pageViewTiming:"page_view_timing",sessionReplay:"session_replay",sessionTrace:"session_trace",softNav:"soft_navigations",spa:"spa"},u={[c.pageViewEvent]:1,[c.pageViewTiming]:2,[c.metrics]:3,[c.jserrors]:4,[c.spa]:5,[c.ajax]:6,[c.sessionTrace]:7,[c.softNav]:8,[c.sessionReplay]:9,[c.logging]:10,[c.genericEvents]:11},d={[c.pageViewEvent]:o,[c.pageViewTiming]:n,[c.ajax]:n,[c.spa]:n,[c.softNav]:n,[c.metrics]:i,[c.jserrors]:i,[c.sessionTrace]:a,[c.sessionReplay]:a,[c.logging]:s,[c.genericEvents]:"ins"}}},n={};function i(e){var t=n[e];if(void 0!==t)return t.exports;var a=n[e]={exports:{}};return r[e](a,a.exports,i),a.exports}i.m=r,i.d=(e,t)=>{for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.f={},i.e=e=>Promise.all(Object.keys(i.f).reduce(((t,r)=>(i.f[r](e,t),t)),[])),i.u=e=>"nr-rum-1.293.0.min.js",i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),e={},t="NRBA-1.293.0.PROD:",i.l=(r,n,a,o)=>{if(e[r])e[r].push(n);else{var s,c;if(void 0!==a)for(var u=document.getElementsByTagName("script"),d=0;d<u.length;d++){var l=u[d];if(l.getAttribute("src")==r||l.getAttribute("data-webpack")==t+a){s=l;break}}if(!s){c=!0;var f={296:"sha512-M1viQxU/Sd10c/wA0iJyMGykq7mUO4/cNh2pUlWVWSRdp2RUo2Lmen9N19KuzHKjUln7vOC7HGbkzvGvRT/yQg=="};(s=document.createElement("script")).charset="utf-8",s.timeout=120,i.nc&&s.setAttribute("nonce",i.nc),s.setAttribute("data-webpack",t+a),s.src=r,0!==s.src.indexOf(window.location.origin+"/")&&(s.crossOrigin="anonymous"),f[o]&&(s.integrity=f[o])}e[r]=[n];var g=(t,n)=>{s.onerror=s.onload=null,clearTimeout(p);var i=e[r];if(delete e[r],s.parentNode&&s.parentNode.removeChild(s),i&&i.forEach((e=>e(n))),t)return t(n)},p=setTimeout(g.bind(null,void 0,{type:"timeout",target:s}),12e4);s.onerror=g.bind(null,s.onerror),s.onload=g.bind(null,s.onload),c&&document.head.appendChild(s)}},i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.p="https://js-agent.newrelic.com/",(()=>{var e={374:0,840:0};i.f.j=(t,r)=>{var n=i.o(e,t)?e[t]:void 0;if(0!==n)if(n)r.push(n[2]);else{var a=new Promise(((r,i)=>n=e[t]=[r,i]));r.push(n[2]=a);var o=i.p+i.u(t),s=new Error;i.l(o,(r=>{if(i.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var a=r&&("load"===r.type?"missing":r.type),o=r&&r.target&&r.target.src;s.message="Loading chunk "+t+" failed.\n("+a+": "+o+")",s.name="ChunkLoadError",s.type=a,s.request=o,n[1](s)}}),"chunk-"+t,t)}};var t=(t,r)=>{var n,a,[o,s,c]=r,u=0;if(o.some((t=>0!==e[t]))){for(n in s)i.o(s,n)&&(i.m[n]=s[n]);if(c)c(i)}for(t&&t(r);u<o.length;u++)a=o[u],i.o(e,a)&&e[a]&&e[a][0](),e[a]=0},r=self["webpackChunk:NRBA-1.293.0.PROD"]=self["webpackChunk:NRBA-1.293.0.PROD"]||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),(()=>{"use strict";i(374);var e=i(566),t=i(741);class r extends t.W{agentIdentifier=(0,e.LA)(16)}var n=i(860);const a=Object.values(n.K7);var o=i(163);var s=i(908),c=i(863),u=i(261),d=i(241),l=i(944),f=i(701),g=i(773);function p(e,t,i,a){const o=a||i;!o||o[e]&&o[e]!==r.prototype[e]||(o[e]=function(){(0,s.p)(g.xV,["API/"+e+"/called"],void 0,n.K7.metrics,i.ee),(0,d.W)({agentIdentifier:i.agentIdentifier,drained:!!f.B?.[i.agentIdentifier],type:"data",name:"api",feature:u.Pl+e,data:{}});try{return t.apply(this,arguments)}catch(e){(0,l.R)(23,e)}})}function m(e,t,r,n,i){const a=e.info;null===r?delete a.jsAttributes[t]:a.jsAttributes[t]=r,(i||null===r)&&(0,s.p)(u.Pl+n,[(0,c.t)(),t,r],void 0,"session",e.ee)}var h=i(687),v=i(234),b=i(289),y=i(154),_=i(384);const w=e=>y.RI&&!0===e?.privacy.cookies_enabled;function x(e){return!!(0,_.dV)().o.MO&&w(e)&&!0===e?.session_trace.enabled}var k=i(389);class A extends v.W{constructor(e,t){super(e.agentIdentifier,t),this.abortHandler=void 0,this.featAggregate=void 0,this.onAggregateImported=void 0,this.deferred=Promise.resolve(),!1===e.init[this.featureName].autoStart?this.deferred=new Promise(((t,r)=>{this.ee.on("manual-start-all",(0,k.J)((()=>{(0,h.Ak)(e.agentIdentifier,this.featureName),t()})))})):(0,h.Ak)(e.agentIdentifier,t)}importAggregator(e,t,r={}){if(this.featAggregate)return;let a;this.onAggregateImported=new Promise((e=>{a=e}));const o=async()=>{let o;await this.deferred;try{if(w(e.init)){const{setupAgentSession:t}=await i.e(296).then(i.bind(i,663));o=t(e)}}catch(e){(0,l.R)(20,e),this.ee.emit("internal-error",[e]),this.featureName===n.K7.sessionReplay&&this.abortHandler?.()}try{if(!this.#t(this.featureName,o,e.init))return(0,h.Ze)(this.agentIdentifier,this.featureName),void a(!1);const{Aggregate:n}=await t();this.featAggregate=new n(e,r),e.runtime.harvester.initializedAggregates.push(this.featAggregate),a(!0)}catch(e){(0,l.R)(34,e),this.abortHandler?.(),(0,h.Ze)(this.agentIdentifier,this.featureName,!0),a(!1),this.ee&&this.ee.abort()}};y.RI?(0,b.GG)((()=>o()),!0):o()}#t(e,t,r){switch(e){case n.K7.sessionReplay:return x(r)&&!!t;case n.K7.sessionTrace:return!!t;default:return!0}}}var S=i(630),T=i(614);class R extends A{static featureName=S.T;constructor(e){var t;super(e,S.T),this.setupInspectionEvents(e.agentIdentifier),t=e,p(u.Fw,(function(e,r){"string"==typeof e&&("/"!==e.charAt(0)&&(e="/"+e),t.runtime.customTransaction=(r||"http://custom.transaction")+e,(0,s.p)(u.Pl+u.Fw,[(0,c.t)()],void 0,void 0,t.ee))}),t),this.ee.on("api-send-rum",((e,t)=>(0,s.p)("send-rum",[e,t],void 0,this.featureName,this.ee))),this.importAggregator(e,(()=>i.e(296).then(i.bind(i,108))))}setupInspectionEvents(e){const t=(t,r)=>{t&&(0,d.W)({agentIdentifier:e,timeStamp:t.timeStamp,loaded:"complete"===t.target.readyState,type:"window",name:r,data:t.target.location+""})};(0,b.sB)((e=>{t(e,"DOMContentLoaded")})),(0,b.GG)((e=>{t(e,"load")})),(0,b.Qr)((e=>{t(e,"navigate")})),this.ee.on(T.tS.UPDATE,((t,r)=>{(0,d.W)({agentIdentifier:e,type:"lifecycle",name:"session",data:r})}))}}var E=i(843),N=i(878),j=i(782);class I extends A{static featureName=j.T;constructor(e){super(e,j.T),y.RI&&((0,E.u)((()=>(0,s.p)("docHidden",[(0,c.t)()],void 0,j.T,this.ee)),!0),(0,N.sp)("pagehide",(()=>(0,s.p)("winPagehide",[(0,c.t)()],void 0,j.T,this.ee))),this.importAggregator(e,(()=>i.e(296).then(i.bind(i,350)))))}}class O extends A{static featureName=g.TZ;constructor(e){super(e,g.TZ),y.RI&&document.addEventListener("securitypolicyviolation",(e=>{(0,s.p)(g.xV,["Generic/CSPViolation/Detected"],void 0,this.featureName,this.ee)})),this.importAggregator(e,(()=>i.e(296).then(i.bind(i,373))))}}new class extends r{constructor(e){var t;(super(),y.gm)?(this.features={},(0,_.bQ)(this.agentIdentifier,this),this.desiredFeatures=new Set(e.features||[]),this.desiredFeatures.add(R),this.runSoftNavOverSpa=[...this.desiredFeatures].some((e=>e.featureName===n.K7.softNav)),(0,o.j)(this,e,e.loaderType||"agent"),t=this,p(u.cD,(function(e,r,n=!1){if("string"==typeof e){if(["string","number","boolean"].includes(typeof r)||null===r)return m(t,e,r,u.cD,n);(0,l.R)(40,typeof r)}else(0,l.R)(39,typeof e)}),t),function(e){p(u.Dl,(function(t){if("string"==typeof t||null===t)return m(e,"enduser.id",t,u.Dl,!0);(0,l.R)(41,typeof t)}),e)}(this),function(e){p(u.nb,(function(t){if("string"==typeof t||null===t)return m(e,"application.version",t,u.nb,!1);(0,l.R)(42,typeof t)}),e)}(this),function(e){p(u.d3,(function(){e.ee.emit("manual-start-all")}),e)}(this),this.run()):(0,l.R)(21)}get config(){return{info:this.info,init:this.init,loader_config:this.loader_config,runtime:this.runtime}}get api(){return this}run(){try{const e=function(e){const t={};return a.forEach((r=>{t[r]=!!e[r]?.enabled})),t}(this.init),t=[...this.desiredFeatures];t.sort(((e,t)=>n.P3[e.featureName]-n.P3[t.featureName])),t.forEach((t=>{if(!e[t.featureName]&&t.featureName!==n.K7.pageViewEvent)return;if(this.runSoftNavOverSpa&&t.featureName===n.K7.spa)return;if(!this.runSoftNavOverSpa&&t.featureName===n.K7.softNav)return;const r=function(e){switch(e){case n.K7.ajax:return[n.K7.jserrors];case n.K7.sessionTrace:return[n.K7.ajax,n.K7.pageViewEvent];case n.K7.sessionReplay:return[n.K7.sessionTrace];case n.K7.pageViewTiming:return[n.K7.pageViewEvent];default:return[]}}(t.featureName).filter((e=>!(e in this.features)));r.length>0&&(0,l.R)(36,{targetFeature:t.featureName,missingDependencies:r}),this.features[t.featureName]=new t(this)}))}catch(e){(0,l.R)(22,e);for(const e in this.features)this.features[e].abortHandler?.();const t=(0,_.Zm)();delete t.initializedAgents[this.agentIdentifier]?.features,delete this.sharedAggregator;return t.ee.get(this.agentIdentifier).abort(),!1}}}({features:[R,I,O],loaderType:"lite"})})()})();</script>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js" attr="nomove"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js" attr="nomove"></script>
	<![endif]-->
	<!-- BOOTSTRAP END -->

    

	<style>
		* {box-sizing: border-box;}*:before, *:after {box-sizing: border-box;}a {text-decoration: none;}body {margin: 0;margin-top: 0px;line-height: 1.42857;}h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {font-weight: 500;line-height: 1.1;margin-top: 20px;margin-bottom: 10px;}input, textarea {line-height: inherit;}td, th {padding: 0;}.collapse {display: none;visibility: hidden;}.container {padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;}@media (min-width: 768px) {.container {width: 750px;}}@media (min-width: 992px) {.container {width: 970px;}}@media (min-width: 1200px) {.container {width: 1170px;}}.container-fluid {padding-left: 15px;padding-right: 15px;}img.img-responsive {        max-width: 100%;        height: auto;    }.dropdown {}.dropdown-menu {display:none;}.dropdown-toggle {}.nav {padding-left: 0;margin-bottom: 0;list-style: none;}.nav > li > a {position: relative;display: block;padding: 10px 15px;}.navbar {position: relative;min-height: 50px;margin-bottom: 20px;}.navbar-collapse {padding-right: 15px;padding-left: 15px;overflow-x: visible;-webkit-overflow-scrolling: touch;border-top: 1px solid transparent;-webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);}.navbar-collapse.in {overflow-y: auto;}.navbar-default {}.navbar-header {}.navbar-nav {margin: 7.5px -15px;}@media (min-width: 768px) {.navbar-nav > li {float: left;}.navbar-nav > li > a {padding-top: 10px;padding-bottom: 10px;line-height: 20px;}.navbar-toggle {display: none;}.navbar-collapse {width: auto;border-top: 0;-webkit-box-shadow: none;box-shadow: none;}.navbar-collapse.collapse {display: block !important;height: auto !important;padding-bottom: 0;overflow: visible !important;visibility: visible !important;}.navbar-collapse.in {overflow-y: visible;}.navbar-nav {float: left;margin: 0;}.navbar-nav > li > a {padding-top: 15px;padding-bottom: 15px;}.navbar-header {float: left;}#mainNav ul.nav li.dropdown:hover > ul.dropdown-menu {display: block;    }.navbar-collapse, nav > .container-fluid {padding-left:0px !important;padding-right:0px !important;}}@media (max-width: 767px) {.navbar-nav .open .dropdown-menu {position: static;float: none;width: auto;margin-top: 0;background-color: transparent;border: 0;-webkit-box-shadow: none;box-shadow: none;}}.row {margin-left: -15px;margin-right: -15px;}#adminNav nav {margin-left: -15px;}.carousel.fade {opacity: 1;}.carousel.fade .item {-moz-transition: opacity ease-in-out .7s;-o-transition: opacity ease-in-out .7s;-webkit-transition: opacity ease-in-out .7s;transition: opacity ease-in-out .7s;left: 0 !important;opacity: 0;top:0;position:absolute;width: 100%;display:block !important;z-index:1;}.carousel.fade .item:first-child {top:auto;position:relative;}.carousel.fade .item.active {opacity: 1;-moz-transition: opacity ease-in-out .7s;-o-transition: opacity ease-in-out .7s;-webkit-transition: opacity ease-in-out .7s;transition: opacity ease-in-out .7s;z-index:2;}@media (min-width: 768px) {.menubg nav {float: left !important;}.menubg .dropdown-menu {margin-left: 15px !important;border: 1px solid #F7DC6F !important;}.menubg {min-height: 50px;}.mainMenuItem {padding-left: 15px !important;padding-right: 15px !important;}}#mainNav.navbar-default{background-color:transparent !important;border:0px !important;}#mainNav.navbar-default .navbar-nav > .open > a, #mainNav.navbar-default .navbar-nav > .open > a:hover, #mainNav.navbar-default .navbar-nav > .open > a:focus{background-color:transparent !important;border:0px !important;}#mainNav .dropdown-menu,#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:hover,#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:focus{background-color:#F7DC6F !important;border:0px !important;}#mainNav.navbar-default .navbar-nav > li > a, #mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a, #mainNav.navbar-default .navbar-nav > li > a:hover, #mainNav.navbar-default .navbar-nav > li > a:focus, #mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:hover, #mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:focus{color:#1A5276 !important;}#mainNav.navbar-default .navbar-nav > li > a:hover, #mainNav.navbar-default .navbar-nav > .open > a, #mainNav.navbar-default .navbar-nav > .open > a:hover, #mainNav.navbar-default .navbar-nav > .open > a:focus{color:#1A5276 !important;}#mainNav .dropdown-menu > li > a{color:#1A5276 !important;background-color:#F7DC6F !important;border:0px !important;}#mainNav .dropdown-menu > li > a:hover, #mainNav .dropdown-menu > li > a:focus{color:#1A5276 !important;background-color:#F7DC6F !important;}.menubg{z-index:3 !important;}.menubg .navbar{min-height:30px !important;margin-bottom:0px !important;}#main-website-content .btn-add-to-cart{color:#f6f6f6 !important;padding-left:60px !important;padding-right:60px !important;transition-duration:0.2s;background:#5bc050 !important;}#main-website-content .btn-add-to-cart:hover{color:#fff !important;transition-duration:0.2s;background:#4BB340 !important;}.btn-add-to-waitlist{color:#f6f6f6 !important;padding-left:60px !important;padding-right:60px !important;transition-duration:0.2s;background:#999999 !important;}.btn-add-to-waitlist:hover{color:#fff !important;transition-duration:0.2s;background:#777 !important;}#main-website-content .btn-add-to-improved-waitlist{color:#f6f6f6 !important;padding-left:20px !important;padding-right:20px !important;transition-duration:0.2s;background:#ff8c00 !important;}.menubg .nav > li{margin-bottom:0px !important;}.menubg > .container{padding:0px !important;}.mainMenuItem{font-size:24px !important;font-family:Open Sans Condensed, sans-serif  !important;font-weight:300 !important;color:#1A5276 !important;}html{font-size:1.125em !important;}body{font-family:Open Sans Condensed, sans-serif  !important;color:#808080 !important;font-size:inherit !important;margin:0px;padding:0px;margin-top:0px;height:100%;}FORM{display:inline !important;}H1, H2, H3, H4, H5{color:#ff9494 !important;font-family:Cookie, sans-serif !important; font-weight: normal !important;font-size:2.1em !important;}a:not(.ignore-site-layout-styles a), a:visited:not(.ignore-site-layout-styles a){color:#7bb2d4 !important;font-weight: !important;}a:hover:not(.ignore-site-layout-styles a){text-decoration:none !important;color:#ff9494 !important;}A:active{outline:none !important;}:focus{-moz-outline-style:none !important;}LI{margin-bottom:8px !important;}.pageDiv{height:auto !important; height:100%;min-height:100%;margin:0 auto;}.secondaryPageDiv{height:auto !important; height:100%;min-height:100%;margin:0 auto;}.bgFooter{background:#83bde1 url(https://media.rainpos.com/6009/footer_image.png) repeat;}.footer, .footer:hover, .footer:visited{color:#fff !important; text-transform: uppercase !important;font-size:1em !important;}.main1ColumnWidth h1, .main1ColumnWidth h2, .main1ColumnWidth h3{color:#ff9494;font-family:Cookie, sans-serif !important; font-weight: normal;font-size:2.1em;}.main1ColumnWidth a{color:#7bb2d4;}.main1ColumnWidth a:hover{text-decoration:none;color:#ff9494;}.secondaryMain1ColumnWidth h1, .secondaryMain1ColumnWidth h2, .secondaryMain1ColumnWidth h3{color:#ff9494;font-family:Cookie, sans-serif !important; font-weight: normal;font-size:2.1em;}.secondaryMain1ColumnWidth a{color:#7bb2d4;}.secondaryMain1ColumnWidth a:hover{text-decoration:none;}.paddingSmall{padding:5px;}.paddingMedium{padding:10px;}.paddingLarge{padding:20px;}.paddingXLarge{padding:30px;padding-top:20px;}    .btnViewCart {        cursor: pointer;        color: rgb(255, 255, 255);        font-size: 16px;        padding: 5px;        text-shadow: 0px -1px 0px rgba(30, 30, 30, 0.8);        -webkit-border-radius: 30px;        -moz-border-radius: 30px;        border-radius: 30px;        background: rgb(40, 40, 40);        background: -moz-linear-gradient(90deg, rgb(40, 40, 40) 30%, rgb(84, 84, 84) 70%);        background: -webkit-linear-gradient(90deg, rgb(40, 40, 40) 30%, rgb(84, 84, 84) 70%);        background: -o-linear-gradient(90deg, rgb(40, 40, 40) 30%, rgb(84, 84, 84) 70%);        background: -ms-linear-gradient(90deg, rgb(40, 40, 40) 30%, rgb(84, 84, 84) 70%);        background: linear-gradient(0deg, rgb(40, 40, 40) 30%, rgb(84, 84, 84) 70%);        -webkit-box-shadow: 0px 2px 1px rgba(130, 130, 130, 0.75);        -moz-box-shadow:    0px 2px 1px rgba(130, 130, 130, 0.75);        box-shadow:         0px 2px 1px rgba(130, 130, 130, 0.75);        border-bottom: 2px solid #000;        border-left: 2px solid #333;        border-right: 2px solid #333;        border-top: 2px solid #333;    }@media (max-width: 767px) {.navbar-default {background-color: #F7DC6F;}.navbar-default .navbar-collapse, .navbar-default .navbar-form {border: 0px;}}.dlgWaitList > .ui-dialog-titlebar {background: #f2f2f2 !important;font-size: 16px;font-family: "Arial";color: #515151;text-transform: uppercase;font-weight: 700;border: 0px;}.dlgWaitList > .ui-dialog-titlebar > .ui-dialog-titlebar-close {background: #f2f2f2 !important;border: 0px;}.dlgWaitList #overlayWaitListForm {padding: 0px;}.dlgWaitList .form-container {margin: 25px;}.dlgWaitList .form-input {-webkit-border-radius: 3px;border-radius: 3px;width: 100%;font-size: 14px;font-family: "Arial";border: 1px solid #d7d8dd;padding: 10px;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;}.dlgWaitList .form-title {font-size: 14px;font-family: "Arial";color: #9c9c9c;margin-bottom: 5px;}.dlgWaitList .product-name {font-size: 14px;font-family: "Arial";color: #515151;font-weight: 700;}.dlgWaitList .glyphicon .glyphicon-remove {font-size: 16px;}.dlgWaitList .form-row {margin-bottom: 25px;}.dlgWaitList .wait-list-btn {color: #fff;padding: 10px;font-family: "Arial";text-align: center;display: block;width: 100%;background-color: #5bc050;border: none;-webkit-border-radius: 3px;border-radius: 3px;}.dlgWaitList .wait-list-btn:hover {background-color: #4BB340;}.dlgWaitList input:focus {color:#515151;}#waitlist-wrapper .product-add-waitlist {
    border-radius: 4px!important;
    border: 1px solid #ddd!important;
    background: #FC971F!important;
    display: block!important;
    padding: 16px!important;
    font-family: Roboto, sans-serif;
    font-size: 14px!important;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    letter-spacing: 0.28px;
    height: 50px!important;
    color: #fff!important;
}

#waitlist-wrapper .product-add-waitlist:hover {
    border-radius: 4px!important;
    border: 1px solid #ddd!important;
    background: #FC971F!important;
    cursor: pointer;
    text-decoration: underline!important;
}


	</style>
	
<!-- Figtree Font -->
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;700&display=swap" rel="stylesheet">

<link
  href="https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Poppins:wght@400;600;700&display=swap"
  rel="stylesheet"
/>
<link href="//fonts.googleapis.com/css?family=Cookie|Open+Sans+Condensed:300,300i,700" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Global Site Tag (gtag.js) - Google Analytics -->











	
    
    
    
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;700&display=swap');

/* === Background Wallpaper === */
.homePageBg,
.secondaryPageBg {
  background: #faf8f0 url(https://media.rainpos.com/6009/footer_image.png) repeat !important;
}


/* Adjust header spacing and cleanup weird paddings */
header,
#header,
.header,
.headerContainer {
  padding: 20px 3rem !important;
  margin: 0 auto !important;
  width: 100% !important;
  box-sizing: border-box;
  background: #ffffff;
  border-bottom: 0px solid #eee;
}

/* === HEADER & NAVIGATION === */
#mainNav.navbar-default {
    background-color: #f6f6f6 !important;
    border: 0px !important;
}

#mainNav .nav > li > a {
    color: #1a1a1a !important;
    background-color: #F6F6F6 !important;
    font-weight: 600;
    text-transform: uppercase;
    padding: 1rem 1.25rem;
    display: inline-block;
    text-decoration: none !important;
    transition: all 0.2s ease-in-out;
}

#mainNav .nav > li > a:hover,

#mainNav .nav > li > a:focus,

#mainNav.navbar-default .navbar-nav > li > a:hover,

#mainNav.navbar-default .navbar-nav > li > a:focus,

#mainNav .navbar-nav > li.open > a.dropdown-toggle:hover {
    color: #D54D52 !important;
    text-decoration: underline !important;
}

#mainNav .navbar-nav > li.open > a.dropdown-toggle {
    background-color: #F6F6F6 !important;
    color: #D54D52 !important;
    text-decoration: underline !important;
}

#mainNav .dropdown-menu {
    background-color: rgba(255, 255, 255, 0.85) !important;
    border: none !important;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    border-radius: 4px;
}

#mainNav .dropdown-menu > li > a {
    color: #1A1A1A !important;
    font-weight: 500;
    padding: 0.5rem 1.25rem;
    display: block;
    background-color: transparent !important;
}

#mainNav .dropdown-menu > li > a:hover,

#mainNav .dropdown-menu > li > a:focus {
    color: #D54D52 !important;
    background-color: rgba(0,0,0,0.03) !important;
    text-decoration: underline;
}

/* === BUTTONS === */
#addToCart,

#main-website-content .btn-add-to-cart,

.selectDateBtn,

#waitlist-wrapper .product-add-waitlist {
    background-color: #D54D52 !important;
    color: #fff !important;
    font-weight: 600;
    border: none !important;
    border-radius: 6px;
    text-transform: uppercase;
    transition: background-color 0.3s ease;
}

#addToCart:hover,

#main-website-content .btn-add-to-cart:hover,

.selectDateBtn:hover,

#waitlist-wrapper .product-add-waitlist:hover {
    background-color: #b94348 !important;
    color: #fff !important;
    text-decoration: underline;
}



header a,
.header a {
  text-decoration: none !important;
  padding: 0.5rem 1rem !important;
  color: #AB4555 !important;
  font-weight: 200 !important;
  display: inline-block;
}

/* Optional: Center logo */
.header-logo img,
#header img {
  max-height: 60px;
  display: block;
  margin: 0 auto;
}

/* Optional: remove floating behavior */
#maincontent,
body > .container.body,
body > .container-fluid.body {
  max-width: 100% !important;
  margin: 0rem !important;
  padding: 0rem !important;
}

/* === Footer Section Styling === */
.bgFooter {
    background: transparent !important;
    padding: 2rem 0;
    display: flex
;
    justify-content: center;
}


.footer, .footer:hover, .footer:visited {
  background-color: #F6F6F6;
  padding: 0rem 0rem;
  color: #1A1A1A !important;
  text-transform: uppercase;
  font-size: .7rem;
  font-weight: 400;
  font-family: 'Figtree', sans-serif !important;
  text-align: center;
  border-radius: 0px;
  max-width: 1200px;
  width: 100%;
  box-shadow: 0 0px 0px rgba(0,0,0,0.05);
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        .bgFooter {
            background: none !important;
            padding: 2rem 0 !important;
            display: flex !important;
            justify-content: center !important;
            flex-wrap: wrap;
        }
    }
}

/* === Content Containers === */
.pageDiv,
.secondaryPageDiv,
.main1ColumnWidth,
.secondaryMain1ColumnWidth {
  background-color: #F6F6F6;
  padding: 1rem;
  margin: 1 auto;
  border-radius: 12px;
  max-width: 1400px;
  box-shadow: 0 0px 0px rgba(0,0,0,0.05);
}

/* === Typography === */
* {
  font-family: 'Figtree', sans-serif !important;
}

body {
  color: #1A1A1A;
  font-size: 16px;
  line-height: 1.6;
}

h1, h2, h3, h4, h5, h6 {
  font-weight: 700;
  color: #1A1A1A;
}

a {
  color: #D54D52;
  font-weight: 600;
  text-decoration: none;
}

a:hover {
  color: #b94348;
  text-decoration: underline;
}



.selectedDateContainer {
  background-color: transparent;
  color: #AB4555 !important;
  font-weight: 400 !important;
  padding: 6px 0px !important;
  font-size: 14px !important;
  
}

.selectDate .fa-calendar::before {

  content: url('https://cdn-icons-png.flaticon.com/16/747/747310.png');
  display: inline-block;
padding: 6px 6px !important;
  width: 16px;
  height: 10px;
  margin-right: 12px;

}



/* === Custom Styling for Class Date Modal Buttons === */
.selectDateBtn {
  background-color: #AB4555 !important; /* Soft red or blush */
  color: white !important;
  border-radius: 6px !important;
  font-weight: 600 !important;
  padding: 2px 6px !important;
  font-size: 14px !important;
  transition: background-color 0.3s ease;
}

.selectDateBtn:hover {
  background-color: #FF8E8E !important;
  color: #fff !important;
}

#addToCart {
  background-color: #AB4555 !important;
  color: white !important;
  border: none !important;
  border-radius: 6px;
  font-weight: 700;
  letter-spacing: 0.05em;
  font-size: 16px;
  padding: 12px 24px;
  text-transform: uppercase;
}

#addToCart:hover {
  background-color: #FF8E8E !important;
}

#class_item_page .qtyContainer .style-plus-minus-group {
  display: auto;
  align-items: center;
  gap: 10px;
  margin-top: 0px;
}

#class_item_page .style-plus-minus-group .btn {
  padding: 5px 10px;
  font-size: 14px;
  border-radius: 4px;
  height: 34px;
}

#class_item_page .style-plus-minus-group input.form-control {
  text-align: center;
  width: 100px;
  padding: 6px 6px;
  height: 34px;
  font-weight: 600;
}

/* Force vertical stack of category list items */
#filter-category ul,
#filter-category ul li {
  display: block !important;
  width: 100% !important;
  float: none !important;
  text-align: left;
  margin: 2px 0;
}

/* Bold active category */
#filter-category ul li.active,
#filter-category ul li.active a {
  font-weight: 700 !important;
  text-decoration: underline !important;
}

/* Fix missing icons (FontAwesome & Glyphicons), without altering layout */
[class^="glyphicon"], [class*=" glyphicon"],
[class^="fa"], [class*=" fa"] {
  font-family: "FontAwesome", "Glyphicons Halflings" !important;
}

/* === Override NavBar Main Menu Items (Top Row Only) === */
#mainNav.navbar-default .navbar-nav > li > a {
  color: #1a1a1a !important; /* Charcoal */
  font-weight: 600;
  text-transform: uppercase;
  text-decoration: none !important;
  background-color: transparent !important;
  transition: all 0.2s ease;
}

/* === Hover/Active/Focussed State for Main Menu Items === */
#mainNav.navbar-default .navbar-nav > li > a:hover,
#mainNav.navbar-default .navbar-nav > li > a:focus,
#mainNav.navbar-default .navbar-nav > .open > a,
#mainNav.navbar-default .navbar-nav > .open > a:hover,
#mainNav.navbar-default .navbar-nav > .open > a:focus {
  color: #d54d52 !important; /* Soft red */
  background-color:  !important;
  text-decoration: underline !important;
}

/* === GLOBAL FIXES for base RainPOS theme === */
body,
body * {
  font-family: 'Figtree', sans-serif !important;
  color: #1A1A1A !important;
}

h1, h2, h3, h4, h5, h6 {
  color: #1A1A1A !important;
  font-family: 'Figtree', sans-serif !important;
  font-weight: 500 !important;
}

/* Override old link colors */
a:not(.ignore-site-layout-styles a),
a:visited:not(.ignore-site-layout-styles a) {
  color: #D54D52 !important;
  font-weight: 600 !important;
  text-decoration: none !important;
}

a:hover:not(.ignore-site-layout-styles a) {
  color: #b94348 !important;
  text-decoration: underline !important;
}

/* Navbar main links */
#mainNav.navbar-default .navbar-nav > li > a {
  color: #1A1A1A !important;
  text-transform: uppercase !important;
  font-weight: 500 !important;
  font-family: 'Figtree', sans-serif !important;
}

#mainNav.navbar-default .navbar-nav > li > a:hover,
#mainNav.navbar-default .navbar-nav > .open > a,
#mainNav.navbar-default .navbar-nav > .open > a:hover,
#mainNav.navbar-default .navbar-nav > .open > a:focus {
  color: #D54D52 !important;
  background: transparent !important;
  text-decoration: underline !important;
}

/* Dropdown menu background override */
#mainNav .dropdown-menu {
  background-color: rgba(255, 255, 255, 0.85) !important;
  border: none !important;
  box-shadow: 0 4px 10px rgba(0,0,0,0.08);
}

#mainNav .dropdown-menu > li > a {
  color: #1A1A1A !important;
  font-weight: 500;
}

#mainNav .dropdown-menu > li > a:hover,
#mainNav .dropdown-menu > li > a:focus {
  color: #D54D52 !important;
  background-color: rgba(0,0,0,0.03) !important;
  text-decoration: underline;
}

.selectDateBtn:hover {
  background-color: #FF8E8E !important;
  color: #fff !important;
}

/* === 1. Fix "Select Date" Button Hover === */
.selectDateBtn:hover {
  background-color: #D54D52 !important;
  color: #fff !important;
  border-radius: 4px;
  text-decoration: underline;
}

/* === 2. Fix "Add to Cart" Button Hover === */
#addToCart:hover,
#main-website-content .btn-add-to-cart:hover {
  background-color: #D54D52 !important;
  color: #fff !important;
}

/* === 3. Fix Waitlist Button (normal + hover) === */
#waitlist-wrapper .product-add-waitlist {
  background: #D54D52 !important;
  color: #fff !important;
  border: none !important;
  border-radius: 6px !important;
  font-family: 'Figtree', sans-serif !important;
  font-size: 16px !important;
  font-weight: 600 !important;
  letter-spacing: 0.03em;
  transition: background-color 0.3s ease;
}

#waitlist-wrapper .product-add-waitlist:hover {
  background: #b94348 !important;
  text-decoration: underline !important;
}

/* === 4. Fix generic button text + layout issues === */
button,
input[type="button"],
input[type="submit"] {
  font-family: 'Figtree', sans-serif !important;
  font-weight: 600;
  border-radius: 6px;
}

/* === 5. Optional: Fix hardcoded yellow fallback dropdowns if any remain === */
.dropdown-menu {
  background-color: rgba(255, 255, 255, 0.9) !important;
  border: none !important;
}

/* === Accordion Arrows for Product Info === */
.accordion-link.arrow::after {
  content: "\f0d9";
  font-family: 'FontAwesome';
  position: absolute;
  right: 0;
  padding-left: 6px;
}

.accordion-link.arrow[aria-expanded="true"]::after {
  content: "\f0d7";
}

.accordion-link.noArrow::after {
  content: "";
}

/* === Accordion Link Hover Cleanup === */
a.accordion-link,
a.accordion-link:link,
a.accordion-link:visited,
a.accordion-link:hover,
a.accordion-link:active {
  color: inherit !important;
  text-decoration: none !important;
}

/* === CLEANED EXPORT FROM DEVTOOLS === */

/* Main Nav Cleanup */
#mainNav.navbar-default {
  background-color: #f6f6f6 !important;
  border: 0px !important;
}

/* Mobile Nav Background */
.navbar-default {
  background-color: #f8f8f8;
  border-color: #e7e7e7;
}

/* Adjust general navbar styling */
.navbar {
  position: relative;
  min-height: 50px;
  margin-bottom: 20px;
  border: 1px solid transparent;
}

/* RainPOS Menubg block inside header */
.menubg .navbar {
  min-height: 30px !important;
  margin-bottom: 0px !important;
}

/* Navbar floating left for desktop */
@media (min-width: 768px) {
  .navbar {
    border-radius: 4px;
  }

  .menubg nav {
    float: left !important;
  }
}

/* Font consistency across header/nav */
body,
body * {
  font-family: 'Figtree', sans-serif !important;
  color: #1A1A1A !important;
}

#mainNav .dropdown-menu {
  background-color: #F6F6F6 !important;
  border: none !important;
  border-radius: 4px;
  box-shadow: 0px 4px 12px rgba(0,0,0,0.05);
  padding: 0.25rem 0;
}

#mainNav .dropdown-menu > li > a {
  color: #1A1A1A !important;
  padding: 0.5rem 1.25rem;
  display: block;
  font-weight: 500;
  background-color: transparent !important;
  transition: all 0.2s ease-in-out;
}

#mainNav .dropdown-menu > li > a:hover,
#mainNav .dropdown-menu > li > a:focus {
  color: #D54D52 !important;
  text-decoration: underline;
  background-color: rgba(0,0,0,0.03) !important;
}

/* Reset all dropdown toggle link styles */
#mainNav .navbar-nav > li > a.dropdown-toggle {
  background-color: #F6F6F6 !important;
  color: #1A1A1A !important;
  font-weight: 400 !important;
  text-transform: uppercase !important;
  text-decoration: none !important;
  transition: all 0.2s ease-in-out;
}

/* Style when hovered */
#mainNav .navbar-nav > li > a.dropdown-toggle:hover {
  color: #D54D52 !important;
  text-decoration: underline !important;
  background-color: #F6F6F6 !important;
}

/* Style when clicked and expanded */
#mainNav .navbar-nav > li.open > a.dropdown-toggle,
#mainNav .navbar-nav > li.open > a.dropdown-toggle:focus,
#mainNav .navbar-nav > li.open > a.dropdown-toggle:hover {
  background-color: #F6F6F6 !important;
  color: #D54D52 !important;
  text-decoration: underline !important;
}

#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a,
#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:hover,
#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:focus {
  background-color: #F6F6F6 !important;
  color: #1A1A1A !important;
  border: none !important;
  text-decoration: none !important;
}

/* Optional: still show red + underline on hover/focus */
#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:hover,
#mainNav.navbar-default .navbar-nav .open .dropdown-menu > li > a:focus {
  color: #D54D52 !important;
  background-color: rgba(0,0,0,0.03) !important;
  text-decoration: underline !important;
}

/* Remove fallback yellow border from mobile or legacy media query */
@media (min-width: 768px) {
  .menubg .dropdown-menu {
    border: none !important;
    margin-left: 15px !important;
  }
}

@media (max-width: 767px) {
  /* Force container padding on mobile */
  .container, .container-fluid {
    padding-left: 1rem !important;
    padding-right: 1rem !important;
  }

  /* Fix pagination line wrapping and spacing */
  .pagination, .pagination li, .pagination li a {
    white-space: nowrap !important;
    overflow-x: auto;
    font-size: 0.95rem;
    max-width: 100%;
  }

  /* Ensure row and columns don't overflow */
  .row {
    margin-left: 0 !important;
    margin-right: 0 !important;
  }

  [class*="col-"] {
    padding-left: 0.5rem !important;
    padding-right: 0.5rem !important;
    float: none !important;
    width: 100% !important;
  }

  /* Fix 'Sort By' section overflowing */
  .sort-options,
  .sort-by,
  select[name="sortby"],
  #sort-by-wrapper {
    display: block !important;
    width: 80% !important;
    max-width: 80% !important;
    margin-top: 10px !important;
    margin-bottom: 1rem !important;
    float: none !important;
    text-align: left !important;
  }

  /* Wrap page results line cleanly */
  .pagination-info,
  .pagination-results,
  .page-count {
    display: block !important;
    text-align: left !important;
    width: 100% !important;
    font-size: 14px !important;
    margin-bottom: 1rem;
  }
}

@media (max-width: 767px) {
  /* Force wrapping inside weird table layout */
  tr.flex-column,
  tr.flex-column td,
  tr.flex-column td .row,
  tr.flex-column td > div,
  .align-center-between,
  .align-right {
    display: block !important;
    width: 100% !important;
    text-align: left !important;
    float: none !important;
    white-space: normal !important;
  }

  /* Give some breathing room between lines */
  .align-center-between {
    margin-bottom: 1rem !important;
  }

  /* Make "Sort By" dropdown fit container */
  .align-right .col-md-3,
  .align-right .col-md-9 {
    display: block !important;
    width: 100% !important;
    padding: 0 !important;
  }

  .align-right span {
    display: block;
    margin-bottom: 0.5rem;
    font-size: 12px;
    font-weight: 300;
  }

  .align-right select {
    width: 100% !important;
    font-size: 12px;
  }

  /* Pagination cleanup */
  .align-center-between a,
  .align-center-between b {
    display: inline-block;
    font-size: 12px !important;
  }

  .align-center-between {
    font-size: 12px;
    word-wrap: break-word;
  }
}

.filter-pill-item {
  position: relative;
  margin-bottom: 1px;
  border: 1px solid #a9444242;
  border-radius: 15px;
  cursor: default;
  display: -webkit-box;
  max-width: 350px;
  opacity: 1;
  transition: opacity 0.3s ease-in-out;
  background: #ffffff;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 500;
  color: #d54d52;
}

@media (max-width: 768px) {

  web-site-facets {
    color: #1a1a1a;
  }

  web-site-facets .categories-panel {
    margin-top: 12px;
    padding-bottom: 8px;
  }

  web-site-facets .facet-list {
    list-style: none;
    margin: 0;
    padding: 0;
  }

  web-site-facets .list-link {
    color: #1a1a1a;
    cursor: pointer;
    font-size: 12px;
  }

@media (max-width: 599px) {
  #cartDivMobile {
    visibility: visible !important;
    position: fixed !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    background-color: #D54D52 !important; 
    color: #ffffff !important; 
    font-size: 16px !important;
    padding: 12px 16px !important;
    border-top: 0px solid #ccc;
    z-index: 9999;
  }
}

/* Optional: Hide desktop cart bar on mobile */
@media (max-width: 599px) {
  #cartDiv {
    visibility: hidden !important;
  }
}

/* Restore desktop cart bar on larger screens */
@media (min-width: 600px) {
  #cartDiv {
    visibility: visible !important;
    position: absolute !important;
    right: 0 !important;
    top: 0 !important;
    background-color: #D54D52 !important; /* red background for visibility */
    color: #fff !important;
  }

  #cartDivMobile {
    visibility: hidden !important;

  }

#formNewsLetternewsLetterForm1 .btnNewsletterSignup {
  background-color: #D54D52 !important;
  color: #ffffff !important;
  font-size: 14px !important;
  padding: 10px 15px !important;
  border: none !important;
  border-radius: 6px;
  font-weight: 600;
  text-transform: uppercase;
  transition: background-color 0.3s ease;
}

#formNewsLetternewsLetterForm1 .btnNewsletterSignup:hover {
  background-color: #b94348 !important;
  color: #ffffff !important;
  text-decoration: underline;
}
}

/* ==== Class Page Redesign (Desktop) ==== */
#class_item_page .row {
  display: flex;
  flex-wrap: wrap;
  margin-top: 20px;
  gap: 10px;
}

/* Title */
#class_item_page h1 {
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 10px;
  font-family: 'Figtree', sans-serif;
  text-align: center;
}

/* Image Column */
#class_item_page .col-sm-6:first-of-type {
  flex: 1 1 45%;
  max-width: 600px;
}

/* Content Column */
#class_item_page .col-sm-6:last-of-type {
  flex: 1 1 45%;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* Price */
#class_item_page .priceContainer {
  font-size: 24px;
  font-weight: 600;
  color: #D54D52;
  font-family: 'Figtree', sans-serif;
  text-align: left;
}

/* Attendance */
#class_item_page .attendanceContainer label {
  font-weight: 500;
  margin-bottom: 5px;
  display: inline-block;
}

/* Quantity Selector */
#class_item_page .style-plus-minus-group {
  max-width: 160px;
}

/* Date Picker Buttons */
.selectDateBtn, .selectDate {
  background-color: #D54D52;
  color: white;
  border: none;
  padding: 6px 12px;
  font-weight: 500;
  font-size: 14px;
  border-radius: 4px;
  margin-top: 5px;
}

.selectDateBtn:hover,
.selectDate:hover {
  background-color: #AB4555;
}

/* Add to Cart Button */
#addToCart {
  background-color: #1a1a1a;
  color: white;
  padding: 12px 16px;
  border: none;
  font-weight: 600;
  font-size: 16px;
  border-radius: 6px;
  margin-top: 10px;
}

#addToCart:hover {
  background-color: #444;
}

/* ==== Mobile Styles ==== */
@media (max-width: 767px) {
  #class_item_page .row {
    flex-direction: column;
  }

  #class_item_page .col-sm-6 {
    flex: 1 1 100%;
    max-width: 100%;
  }

  .priceContainer, .attendanceContainer, .selectDateContainer {
    text-align: center !important;
  }

  #addToCart {
    width: 100%;
  }
}
/* === CLASS PAGE MOBILE CLEANUP === */
@media (max-width: 768px) {
  #class_item_page h1 {
    font-size: 1.8rem;
    line-height: 1.2;
    text-align: center;
    margin-bottom: 0px;
  }

  #class_item_page .classTitleContainer hr {
    margin: 10px auto 20px;
    width: 60%;
  }

  #class_item_page .col-sm-6 img {
    width: 100%;
    height: auto;
    margin-bottom: 0px;
  }

  #class_item_page .col-sm-6 {
    width: 100%;
    padding: 0 0px;
    box-sizing: border-box;
  }

  #class_item_page .priceContainer {
    text-align: center !important;
    font-size: 1.6rem;
    margin-top: 0px;
  }

  #class_item_page .selectDateContainer,
  #class_item_page .attendanceContainer {
    text-align: center !important;
    margin-top: 0px;
  }

  #class_item_page #addToCart {
    display: block;
    width: 100%;
    margin: 0px auto;
    font-size: 1.1rem;
  }

  #class_item_page p {
    font-size: 1rem;
    text-align: center;
    margin: 0px 0 0px;
  }


/* ========== SHOP PRODUCT CARDS FIXED ========== */

/* Force container to max width */
.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}

/* Fix broken table layout and remove spacing */
table[width="100%"][border="0"] {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 30px;
}

/* Style each product card container (the TD) */
td[valign="top"] {
  width: 100%;
  max-width: 300px;
  background: #fff;
  padding: 16px;
  border: 1px solid #ddd;
  border-radius: 12px;
  text-align: center;
  vertical-align: top;
  box-shadow: 0 1px 4px rgba(0,0,0,0.1);
  transition: box-shadow 0.3s ease;
}

td[valign="top"]:hover {
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

/* Fix product image sizing */
td[valign="middle"] img {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
  display: block;
  margin: 0 auto 10px;
}

/* Ensure product name links are clickable and styled */
center > a[href*="/shop/"] {
  font-size: 16px;
  font-weight: 600;
  color: #222;
  text-decoration: none;
  display: inline-block;
  margin-top: 6px;
}

center > a[href*="/shop/"]:hover {
  text-decoration: underline;
  color: #B53A3A;
}

/* Fix layout for table rows */
tr {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}

/* Remove unwanted lightbox styles or overlay interference */
#overlay,
#lightbox,
#lightboxIframe {
  display: none !important;
  visibility: hidden !important;
  pointer-events: none !important;
  height: 0 !important;
  width: 0 !important;
}

/* Hide any blank spacing cells */
td:empty {
  display: none;
}

/* Make breadcrumb area readable */
.breadcrumbs {
  font-size: 14px;
  margin-bottom: 12px;
  color: #777;
}
.breadcrumbs a {
  color: #777;
  text-decoration: none;
}
.breadcrumbs a:hover {
  color: #B53A3A;
  text-decoration: underline;
}

/* ========== OPTIONAL FILTER PILL FIXES ========== */
#filterPillsWrapper {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 10px 0;
}
#filterPillsWrapper span,
#filterPillsWrapper a {
  background: #eee;
  border-radius: 20px;
  padding: 6px 12px;
  font-size: 14px;
  color: #333;
  text-decoration: none;
}
#filterPillsWrapper a:hover {
  background: #d54d52;
  color: white;
}



/* —————————————————————————————————————————————————————————
   Buttons
   ————————————————————————————————————————————————————————— */



/* —————————————————————————————————————————————————————————
   Mobile cart bar (bottom)
   ————————————————————————————————————————————————————————— */
.mobile-cart-bar {
  position:        fixed;
  bottom:          0;
  left:            0;
  width:           100%;
  background-color: var(--cart-bar-bg);
  color:            var(--cart-bar-text);
  padding:          0.75rem;
  text-align:       center;
  font-family:      var(--font-family);
  z-index:          1000;
}
.mobile-cart-bar * {
  /* force all text/icons inside to use your light text color */
  color: var(--cart-bar-text) !important;
}

 /* Fix layout for table rows */
                    tr {
                        display: flex;
                        
                     
                        gap: 20px;
                        align-content: stretch;
                        flex-direction: column;
                        
                        
                        justify-content: flex-start;
                        flex-wrap: nowrap;
                        align-items: center;
                    }

.modal-content {
    position: relative;
    display: flex;
    background-color: #fff;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
( … Skipping 2 matching lines … )
    border: 1px solid rgba(0,0,0,.2);
    border-radius: 6px;
    outline: 0;
    -webkit-box-shadow: 0 3px 9px rgba(0,0,0,.5);
    box-shadow: 0 3px 9px rgba(0,0,0,.5)
    box-shadow: 0 3px 9px rgba(0,0,0,.5);
    align-content: flex-start;
    flex-direction: column;
    justify-content: center;
    align-items: stretch;
}



tbody {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
    flex-direction: row;
}

/* Fix floating select button in modal */
.selectDateBtn {
  position: relative !important;      /* Cancel absolute/fixed styles */
  display: inline-block !important;
  margin: 0 auto !important;
  padding: 10px 16px !important;
  font-size: 14px !important;
  font-weight: bold;
  background-color: #D54D52 !important; /* Your red brand color */
  color: white !important;
  border: none !important;
  border-radius: 6px;
  box-shadow: none !important;
  text-transform: uppercase;
  width: auto !important;
  height: auto !important;
}

/* Optional: If the button cell is too wide and causes misalignment */
td[style*="width: 90px;"] {
  width: auto !important;
  text-align: right;
  padding-right: 15px;
}



@media (max-width: 768px) {
    @media (max-width: 768px) {
        td[valign="top"] {
            width: 100%;
            max-width: 300px;
            background: #ffffff00;
            padding: 10px;
            border: 0px solid #ddd;
            border-radius: 12px;
            text-align: center;
            vertical-align: top;
            box-shadow: 0 0px 0px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
            align-content: center;
            align-items: center;
        }
    }
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        tbody {
            display: flex
;
            justify-content: center;
            flex-direction: column;
            flex-wrap: nowrap;
            align-items: center;
        }
    }
}

    @media (max-width: 768px) {
        td[valign="top"]:hover {
            box-shadow: 0 0px 0px rgba(0, 0, 0, 0.15);
        }
    }
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        tr {
            display: flex
;
            gap: 20px;
            align-content: center;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
    }
}




.filter-pill-item {
    position: relative;
    margin-bottom: 4px;
    border: 1px solid #e1e1e100;
    border-radius: 20px;
    cursor: default;
    display: inline-block;
    max-width: 320px;
    transition: none;
    background: #fff;
    padding: 12px;
}

.remove-item-btn {
    padding: 5px 3px;
    position: absolute;
    right: 7px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: transparent;
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        #filterPillsWrapper span, #filterPillsWrapper a {
            background: #eeeeee00;
            border-radius: 20px;
            padding: 5px 14px;
            padding-left: 0px;
            font-size: 12px;
            color: #333;
            text-decoration: none;
        }
    }

@media (max-width: 768px) {
    @media (max-width: 768px) {
        @media (max-width: 768px) {
            @media (max-width: 768px) {
                td[valign="top"] {
                    width: 100%;
                    max-width: 300px;
                    background: #ffffff00;
                    padding: 1px;
                    border: 0px solid #ddd;
                    border-radius: 12px;
                    text-align: left;
                    vertical-align: top;
                    box-shadow: 0 0px 0px rgba(0, 0, 0, 0.1);
                    transition: box-shadow 0.3s ease;
                    align-content: center;
                    align-items: center;
                }
            }
        }
    }
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        @media (max-width: 768px) {
            @media (max-width: 768px) {
                tbody {
                    display: flex
;
                    flex-direction: column;
                }
            }
        }
    }
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        @media (max-width: 768px) {
            tr {
                display: flex
;
                gap: 0px;
                align-content: center;
                flex-direction: row;
                align-items: center;
                text-align: start;
                flex-wrap: wrap;
                justify-content: stretch;
            }
        }
    }
}

@media (max-width: 768px) {
    @media (max-width: 768px) {
        @media (max-width: 768px) {
            @media (max-width: 768px) {
                tbody {
                    display: flex
;
                    justify-content: center;
                    align-items: flex-start;
                    flex-direction: column;
                    align-content: flex-start;
                    flex-wrap: wrap;
                }
            }
        }
    }
}

/* ——— Nested “Sew Days” submenu ——— */

/* 1) Mark it as a positioning parent */
#mainNav .dropdown-submenu {
  position: relative !important;
}

/* 2) Hide its submenu by default */
#mainNav .dropdown-submenu > .dropdown-menu {
  display: none !important;
  position: absolute !important;
  top: 0 !important;
  left: 100% !important;
  margin-left: .2rem !important;
  min-width: 12em !important;
  z-index: 10000 !important;
}

/* 3a) Desktop: hover ? show */
@media (min-width: 768px) {
  #mainNav .dropdown-submenu:hover > .dropdown-menu {
    display: block !important;
  }
}

/* 3b) Mobile: when JS toggles .open on the li */
@media (max-width: 767px) {
  #mainNav .dropdown-submenu.open > .dropdown-menu {
    display: block !important;
    position: static !important;
    margin: 0 !important;
    box-shadow: none !important;
  }
}

/* 4) Little arrow indicator on the right */
#mainNav .dropdown-submenu > a::after {
  content: "?";
  float: right;
  font-size: 0.7em;
  margin-top: 0.2em;
  transition: transform 0.2s ease;
}
@media (max-width: 767px) {
  /* point down on mobile when open */
  #mainNav .dropdown-submenu.open > a::after {
    transform: rotate(90deg);
  }
}


/* ==== SUBMENU ARROW + MOBILE TAP OPEN ==== */

/* 1) Turn Sew Days into a block?level, clickable toggle, with padding for arrow */
#mainNav .dropdown-submenu > a {
  display: block !important;
  position: relative !important;
  padding-right: 2rem !important;
  cursor: pointer !important;
}

/* 2) Use a real Unicode ? (and force a standard font that has it) */
#mainNav .dropdown-submenu > a::after {
  content: "\25B6" !important;             /* ? */
  font-family: Arial, sans-serif !important;
  position: absolute !important;
  right: 1rem !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  transition: transform 0.2s ease !important;
}

/* 3) On mobile, hide/show the nested menu via .open */
@media (max-width: 767px) {
  /* keep it out of the flow so it pushes nothing */
  #mainNav .dropdown-submenu > .dropdown-menu {
    display: none !important;
    position: static !important;
    margin: 0 !important;
    box-shadow: none !important;
    padding-left: 1rem !important;
  }
  /* reveal when .open is toggled */
  #mainNav .dropdown-submenu.open > .dropdown-menu {
    display: block !important;
  }
  /* rotate arrow down when open */
  #mainNav .dropdown-submenu.open > a::after {
    transform: translateY(-50%) rotate(90deg) !important;
  }
}

/* 4) Keep desktop hover working exactly as before */
@media (min-width: 768px) {
  #mainNav .dropdown-submenu:hover > .dropdown-menu {
    display: block !important;
    position: absolute !important;
    left: 100% !important;
    top: 0 !important;
    margin-left: .2rem !important;
    min-width: 12em !important;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08) !important;
  }
}





		
	</style>
</head>
<body class="secondaryPageBg">
<!-- 43-page.tpl BODY -->





<div id="main-website-content" class="secondaryPageDiv">
	<!-- Accessibility stuff -->
	<a href="#skip-navigation" class="sr-only visible-focused">Skip Navigation</a>
	<a href="/website-accessibility.htm" class="sr-only visible-focused">Website Accessibility</a>

	<div class="header-content">
		<!-- column0_components -->
		<div
    id="vue-website-component-7119776"
    data-component-type="content_module"
    data-options="{&quot;settings&quot;:{&quot;background&quot;:{&quot;image&quot;:{&quot;path&quot;:&quot;&quot;},&quot;color&quot;:&quot;&quot;,&quot;repeat&quot;:&quot;&quot;,&quot;size&quot;:&quot;cover&quot;},&quot;rowClasses&quot;:&quot;header-bg&quot;,&quot;containerClasses&quot;:&quot;&quot;,&quot;width&quot;:&quot;normal&quot;,&quot;margins&quot;:{&quot;top&quot;:&quot;5&quot;,&quot;bottom&quot;:&quot;20&quot;,&quot;left&quot;:&quot;0&quot;,&quot;right&quot;:&quot;0&quot;}},&quot;content&quot;:&quot;&lt;div style=\u0022text-align: center; padding: 1rem 0;\u0022&gt;&lt;img src=\u0022https:\/\/media.rainpos.com\/7381\/LOGO_Final_Box_Car_Quilts_20250612133320.svg\u0022 alt=\u0022Box Car Quilts Logo\u0022 style=\u0022width: 200px; height: 200px;\u0022 \/&gt;&lt;\/div&gt;&quot;}"
    data-editable="false"
    data-page-id="0"
    data-component-id="7119776"
    data-preview-component-id="0"
    data-original-component-id="0"
    data-sequence="100"
    data-config="null"
    data-column-id="header"
></div>
	</div>
    <!-- navigation -->
	
<div class="menubg">
	<div class="container">

		<nav id="mainNav" class="navbar navbar-default">
			<div class="container-fluid">

				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header" style="padding-left:15px; padding-right:15px;">
					<button type="button" class="navbar-toggle collapsed" style="width: 100%; float: left;" data-toggle="collapse" data-target="#navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						&#9776; Menu
					</button>
					<!--span class="navbar-brand visible-xs-block" data-toggle="collapse" href="#">Menu</span-->
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a href="https://www.boxcarquilts.com/" class="mainMenuItem">Home</a></li><li class="dropdown">
	<a href="#" class="dropdown-toggle mainMenuItem" data-toggle="dropdown" role="button" aria-expanded="false">Classes</a>
	<ul class="dropdown-menu" role="menu">
		<li><a href="https://www.boxcarquilts.com/classes">All Classes</a></li><li><a href="">Sew Days</a></li><li><a href="https://www.boxcarquilts.com/module/class/602532/beginner-cross-stitch-class">Beginner Cross Stitch Class</a></li><li><a href="https://www.boxcarquilts.com/module/class/564139/2025-tamarack-jacket-classes">Tamarack Jacket Class</a></li><li><a href="https://www.boxcarquilts.com/module/class/587216/cookie-cutter-beginner-applique-class">Cookie Cutter Beginner Applique Class</a></li>
	</ul>
</li><li class="dropdown">
	<a href="#" class="dropdown-toggle mainMenuItem" data-toggle="dropdown" role="button" aria-expanded="false">Events</a>
	<ul class="dropdown-menu" role="menu">
		<li><a href="https://www.boxcarquilts.com/module/events.htm?year=2025&amp;month=Jul&amp;day=19&amp;eventId=4185484">Sidewalk Sale | July 19th</a></li><li><a href="https://www.boxcarquilts.com/module/class/604076/destash-dash">Destash Dash | Aug. 9th</a></li>
	</ul>
</li><li class="dropdown">
	<a href="#" class="dropdown-toggle mainMenuItem" data-toggle="dropdown" role="button" aria-expanded="false">Shop</a>
	<ul class="dropdown-menu" role="menu">
		<li><a href="https://www.boxcarquilts.com/shop/All-Products.htm">All Products</a></li><li><a href="https://www.boxcarquilts.com/shop/Fabric.htm">Fabric</a></li><li><a href="https://www.boxcarquilts.com/shop/Kits.htm">Kits</a></li><li><a href="https://www.boxcarquilts.com/shop/Patterns.htm">Patterns</a></li><li><a href="https://www.boxcarquilts.com/shop/Handwork.htm">Handwork</a></li>
	</ul>
</li><li><a href="https://www.boxcarquilts.com/contact-us.htm" class="mainMenuItem">Contact Us</a></li><li><a href="https://www.boxcarquilts.com/about-us.htm" class="mainMenuItem">About Us</a></li><li><a href="https://www.boxcarquilts.com/c/account/login.php" class="mainMenuItem">Login</a></li>
					</ul>
				</div>

			</div>
		</nav>
	</div>
</div>


	<!-- Accessibility stuff -->
	<span id="skip-navigation"></span>

	<div class="body-content">
		<link href="/1723204578/bootflat/css/visitor-account-login.css" rel="stylesheet" type='text/css'><link href="/1723204578/bootflat/css/visitor-account-login.css" rel="stylesheet" type='text/css'>
<div style="" class="">
    <div class="container-fluid ">
        <div class="row paddingLarge" style="padding-left: 0px; padding-right: 0px; padding-top: 0px; padding-bottom: 0px; ">
            <div class="container-fluid">
                <div class="row">
                    <div>
                    
                        <div class="col-xs-2 hidden-xs">
                        </div>
                                                
                        <div class="col-xs-12 col-sm-8" style="min-height:200px;">
                            <form class="form-horizontal" method="POST"><input type="hidden" name="form_version" value="2">
            <div class="visitorLoginContainer">
            <h1>Account Login</h1>
            <div class="emailField">
                <input autofocus="autofocus" name="email" id="email" class="form-control" type="email" placeholder="Email Address" required>
                <span class="fa fa-envelope"></span>
            </div>
            <div class="passwordField">
                <input placeholder="Password" name="password" id="password" class="form-control" type="password" required>
                <span class="fa fa-lock"></span>
            </div>
            
            <button name="submitBtn" id="submitBtn" value="Login" class="btn btn-lg btn-primary" type="submit">Sign In</button>
            <div>
            <a href="/c/account/forgot.php">Forgot Password?</a>
            <a class="pull-right" href="/c/account/create.php">Create Account</a>
            </div>
            </div>
        </form>
                        </div>
                        
                        <div class="col-xs-2 hidden-xs">                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
	</div>
    <!-- footer -->
	<div class="bgFooter">
	
	<div class="container footer" style="height: auto; text-align:center; ">
		<br>
		<br>
		<a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/">Home</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://55462240-9bac-42bc-956f-e8cf69591477.rain-pods.com/classes">Classes</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/events.htm">Events</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/shop.htm">Shop</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/contact-us.htm">Contact Us</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/about-us.htm">About Us</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/site-map.htm">Site Map</a> &nbsp; | &nbsp; <a style="font-weight: normal; font-size: 12px;" class="footer" href="https://www.boxcarquilts.com/terms-conditions.htm">Terms and Conditions</a>
                    
                    
                    
                    
                    
                    
                    





<div id="cartDiv" style="display: none; top: 0; right: 0; width: 180px; text-align: center; padding: 0 5px 5px; z-index: 10;"></div>
<div id="cartDivMobile"></div>


        
                    
                    <!-- Cart Styles -->
                    <style type="text/css">
                        @media (max-width: 600px)
                        {
                            #cartDiv {
                                visibility: hidden;
                            }
                            #cartDivMobile {
                                visibility: visible;
                                position: fixed;
                                bottom: 0;
                                left : 0;
                                top: auto;
                                width: 100%;
                                background-color: #111;
                                color: #ddd;
                                font-size: 14px;
                                opacity: 1;
                            }
                        }
                        @media (min-width: 600px)
                        {
                            #cartDiv {
                                visibility: visible;
                                position: absolute;
                                right: 0px;
                                top: 0px;
                                background-color: #000000;
                            }
                            #cartDivMobile {
                                visibility: hidden;
                            }
                        }

                        div > div#cartDiv {
                            position: fixed;
                            background: url(https://siteimages.s3.amazonaws.com/cart-bg-1a.png) repeat;
                        }
                    </style>
                    <!-- Yup, this comment is here for a reason. -->
		<div style="height: 10px;"></div>
		Copyright &copy; 2007-2025 - Box Car Quilts<br>
		<a class="footer" style="font-weight: normal;" href="https://www.likesew.com">Website Design</a> by Like Sew<br>
		
		<br>
		<br>
	</div>
</div>



</div>

<!-- 43-page.tpl CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css"/>

<!-- 43-page.tpl JS -->
	
















	
<script type="text/javascript" src="https://images.rainpos.com/jquery.tools.min.js" attr="nomove"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js" attr="nomove"></script>
<script type="text/javascript" src="https://images.rainpos.com/jquery-migrate-1.2.1.min.js" attr="nomove"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js" attr="nomove"></script>
<script type="text/javascript" src="https://images.rainpos.com/json2.js" attr="nomove"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js" attr="nomove"></script>










<!-- 43-page.tpl DONE -->



<script async src="https://www.googletagmanager.com/gtag/js?id=UA-80179900-37"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-80179900-37');
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
  if (!window.location.href.includes("/module/class/602532/beginner-cross-stitch-class")) return;

  const observer = new MutationObserver(() => {
    const label = document.querySelector(".attendeesContainer label");

    if (label && !label.dataset.modified) {
      label.dataset.modified = "true";

      // Grab the <ul> that contains the input(s)
      const ul = label.querySelector("ul");
      if (ul) {
        // Replace label text only
        label.innerHTML = `
          <span style="font-weight: 600;">
            Attendee’s First and Last Name <em>plus</em> any food allergies, please:
          </span><br>
        `;
        label.appendChild(ul);
      }

      // Set placeholder on input(s)
      const input = label.querySelector('input[placeholder="NAME"]');
      if (input) {
        input.placeholder = "Jane Quiltyfriend; peanut allergy";
      }
    }
  });

  const target = document.querySelector(".attendanceContainer");
  if (target) {
    observer.observe(target, {
      childList: true,
      subtree: true
    });
  }
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
  if (!window.location.href.includes("/module/class/604076/destash-dash")) return;

  const observer = new MutationObserver(() => {
    const label = document.querySelector(".attendeesContainer label");

    if (label && !label.dataset.modified) {
      label.dataset.modified = "true";

      // Grab the <ul> that contains the input(s)
      const ul = label.querySelector("ul");
      if (ul) {
        // Replace label text only
        label.innerHTML = `
          <span style="font-weight: 600;">
            Please Note: There is no charge to come to this event to simply shop. Only purchase the $10 reservation if you want to sell items. We will contact you for additional information after you make your reservation. Please include your First & Last Name and E-Mail: 
          </span><br>
        `;
        label.appendChild(ul);
      }

      // Set placeholder on input(s)
      const input = label.querySelector('input[placeholder="NAME"]');
      if (input) {
        input.placeholder = "Jane Quiltyfriend; jane@quiltymail.com";
      }
    }
  });

  const target = document.querySelector(".attendanceContainer");
  if (target) {
    observer.observe(target, {
      childList: true,
      subtree: true
    });
  }
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
  if (!window.location.href.includes("/module/class/604673/saturday-stitchery")) return;

  const observer = new MutationObserver(() => {
    const label = document.querySelector(".attendeesContainer label");

    if (label && !label.dataset.modified) {
      label.dataset.modified = "true";

      // Grab the <ul> that contains the input(s)
      const ul = label.querySelector("ul");
      if (ul) {
        // Replace label text only
        label.innerHTML = `
          <span style="font-weight: 600;">
            Attendee’s First and Last Name <em>plus</em> any food allergies, please:
          </span><br>
        `;
        label.appendChild(ul);
      }

      // Set placeholder on input(s)
      const input = label.querySelector('input[placeholder="NAME"]');
      if (input) {
        input.placeholder = "Jane Quiltyfriend; peanut allergy";
      }
    }
  });

  const target = document.querySelector(".attendanceContainer");
  if (target) {
    observer.observe(target, {
      childList: true,
      subtree: true
    });
  }
});
</script>
<script type="text/javascript" src="/1723204580/site-configuration/js/recaptchaCode.js"></script>
<script src="https://www.google.com/recaptcha/api.js?onload=recaptchaOnload&render=explicit" async defer></script>
<script>var adminUrls = ["quiltstorewebsites.com","my-quiltstorewebsites.com","m3rchantadmin.com","rainadmin.com","posimadmin.com","jewel360.com","musicshop360.com","webcase.io","my-rainadmin.com","ienetworkadmin.com","mybnbwebsite.com","mywebsitepitcrew.com","mytextingreviews.com","unittest.com","my-unittest.com","onyxtesting.com","onyxstaging.com","raindev.com","rain.sacksdevelopment.com"];</script>
<script>
                    window.PayPalUrl = "https://www.paypal.com/cgi-bin/webscr";
                    window.ABCart = "";
                    window.checkoutVersion = "2015C";
                    window.paymentProcessor = "Q_ADYEN";
                    window.CheckoutUrl = "checkout/cart.php";
                    window.EditCartUrl = "checkout/cart.php";
                    window.siteMinimumFraction = "0.5";
                    window.currency = "USD";
                    window.displayCurrency = '';
                    window.displayCurrencySymbol = "$";
                    window.weightUnit = "lbs";
                    window.measurementUnit = "Yard";
                    window.measurementText = "Yard";
                    window.useShipping = "yes";
                    window.domesticCountry = "United States";
                    window.facebookPixelId = "";
                    window.googleAnalyticsId = "";
                    </script>
<script src="/1723204580/products-28.js"></script>
<script>window.cartVersion = 'not-2017';</script>
<script>
    var knobby = JSON.parse('{"bin_location":false,"bulk":true,"module_canonical":true,"customer_notes":false,"dumbbell_labels":true,"email_customization":true,"layaway":true,"newsletter_archive":true,"polls":true,"product_download":true,"product_form":true,"product_kit":true,"product_offline_reserve":true,"product_serialized":true,"allow_subscriptions_settings":true,"product_suggested":true,"product_transfer":true,"product_wait_list":true,"product_yards":true,"quotes":true,"repairs":true,"rto_school_info":false,"services":true,"so":true,"packages":true,"till_quick_pick":false,"taxjar":false,"wos":false,"shopify":false,"web_checkout":true,"website_file_upload":true,"website_forms":true,"website_customer_directory":true,"website_store_locator":true,"scuba_store":false,"walkme":true,"walkme-dev":false,"admin_domain":false,"checkout_enabled":true,"module_website":true,"module_email":true,"module_products":true,"module_classes":true,"module_packages":true,"module_class_packages":false,"module_enhancedCategoryPage":true,"module_pos":true,"module_spreadsheetUpload":true,"module_wholesaleLogin":true,"module_designWall":true,"module_facebookFeatures":true,"module_gallery":true,"module_allcosts":false,"module_rental":false,"module_txtMsg":true,"module_rto":false,"module_inventory_turn":false,"module_reverb":false,"module_social":true,"module_mobile":false,"module_vantiv":false,"module_marketing":true,"module_marketingReviews":true,"module_bin_location":false,"module_ssi":false,"module_use_ssi_sandbox":false,"module_backorders":false,"module_gst":false,"module_online_canada_tax":false,"module_order_location":false,"module_locally":false,"module_loans":false,"module_catalog_options":true,"module_check_duplicate_sn_store":false,"module_subscriptions":false,"module_layaway_reserve_logic":false,"module_purchase_contracts":false,"module_comment_sold":false,"module_customer_po_pos":false,"module_search_through_packrat":true,"module_participate_in_stashify":false,"module_customer_packrat_sync":false,"module_wholesale_shipping":true,"module_sellbrite":false,"module_mms":false,"module_calendarAdmin":false,"module_stashify_reporting":false,"module_support_tax_inclusive_pricing":false,"module_rto_overdue_statements_bulk_edit":false,"module_test_tu_on_prod":false,"module_trial_purchases":false,"module_rto_required_fields_simplified_customer_modal":false,"module_crmGroupsFlag":false,"module_avalara_tax_sandbox_mode":false,"module_add_other_payment_method":false,"module_online_account_management_enhancements":true,"on_all_stores_online_account_management_enhancements":true,"module_paypal_sandbox_mode":false,"module_great_plains_exports":false,"module_till_require_pin":false,"module_view_waive_rto_late_fee":false,"module_facebook_catalog_feed":false,"module_letter_management":false,"module_bye_pendo":false,"module_show_desc_for_till_line_item":false,"module_ebay_integration_flag":false,"module_ebay_sandbox":false,"module_invalid_cart_code":false,"module_shipping_carrier":false,"module_reconciliation":false,"module_weight_cost":false,"module_break_up_ccf_upload":false,"module_autopayment_rto_eod":false,"module_freeze_rto_tax":false,"module_ebay_sandbox_mock":false,"module_facebook_social_posts":false,"module_facebook_shop_integration":false,"module_honor_purchase_of_free_products_setting":false,"module_emails_v2_using_partials":false,"module_rental_inventory_from_products":false,"module_advanced_customer_search":false,"module_return_line_item_edit_icon":false,"module_reverb_orders_sync":false,"module_taxjar":false,"module_taxjar_sandbox":false,"module_recognize_rental_revenue":false,"module_rto_settings_fees":false,"module_finish_out_discount_on_po_ro":false,"module_show_customer_group_and_custom_id_in_till":false,"module_navbar_v2":true,"on_all_stores_navbar_v2":true,"module_pointy_slack_logging":false,"module_pointy_staging":false,"module_reconciliation_memory_size_exhausted":false,"module_printouts_min_height":false,"module_sell_free_online_order":true,"on_all_stores_sell_free_online_order":true,"module_trade_in_tax_calculating":false,"module_temp_till_address":false,"module_changing_price_in_consignment_contract":false,"module_rto_payments_show_to_left_eod":false,"module_logging_incorrect_styled_product":false,"module_completed_status_for_orders":true,"module_pslr_weighted_cost":false,"module_tax_profiles":true,"module_ignore_international_setting_for_non_shipping_items":false,"module_virtual_terminal_sync":true,"on_all_stores_virtual_terminal_sync":true,"module_fix_item_shows_as_available_on_web":false,"module_change-select-to-input-in-disassemble":false,"module_auth_capture_report_service_error":false,"module_paypal_subscription_only":false,"module_clientbook_sandbox_mode":false,"module_online_rto_zero":false,"module_ignore_empty_tax_rates":false,"module_craftalytics_feed":false,"module_fix_customer_overwriting":false,"module_log_interac_refund_attempts":false,"module_dumbbell_margin_between_fix":false,"module_make_request_review_checkbox_on_by_default":false,"module_user-guiding":false,"module_big_company":false,"module_big_slack_logging":false,"module_nmi_emv_payments":false,"module_stone_management":false,"module_add_new_product_types_in_db":false,"module_bulk_rental_billing_functions_on_rto_list":true,"module_dumbbell_1up_fix":false,"module_gift_registry_till_block":false,"module_change_barcode_type":false,"module_jewel_product_type":false,"module_appraisals_main_flag":false,"module_fix_empty_till_sales_tax_report_grouping":false,"module_spreadsheet_uploads_cant_allow_for_duplicate_sku":false,"module_omnichannel_integration":true,"module_display_single_line_item_for_identical_serialized_items_on_RO":false,"module_dont_show_completed_ro_when_ready_to_receive_filter_is_selected":false,"module_qbo_sandbox_mode":false,"module_fake_test_flag":false,"module_fake_test_flag_v2":false,"module_fix_serial_numbers_displayed_on_special_order_ticket_in_ro":false,"module_colorado_retail_delivery_fee":false,"module_remove_coupon_from_cart_if_deleted_and_throw_error":true,"on_all_stores_remove_coupon_from_cart_if_deleted_and_throw_error":true,"module_zpl_debug":false,"module_care_plans":false,"module_flag_backorders_for_rain_payments":false,"module_customer_po_adjust_wo_logic":false,"module_jm_slack_logging":false,"module_jm_sandbox":false,"module_product_page_redesign":false,"module_respect_serialized_condition_for_website_enhanced_view":false,"module_flag_craftalytics_export_item_weight":false,"module_jm_insurance":false,"module_remove_lane_info_from_non_worldpay":false,"module_flag_add_categories_automatically_in_product_upload":true,"on_all_stores_flag_add_categories_automatically_in_product_upload":true,"module_disable_db_log_usage":true,"on_all_stores_disable_db_log_usage":true,"module_flag_migration_upload_score_card":false,"module_refactor_online_rto_price_code":false,"module_fix_custom_field_date_validator":true,"on_all_stores_fix_custom_field_date_validator":true,"module_fix_merge_serial_numbers":false,"module_rto_order_line_details":false,"module_allow_fallback_to_wp_tokens":false,"module_flag_migrate_invoice_customer_by_external_id":true,"on_all_stores_flag_migrate_invoice_customer_by_external_id":true,"module_fix_items_quantity_for_so":false,"module_flag_test_subscription_email_store_logo":false,"module_fix_product_info_modal":false,"module_stripe_accounts_per_location":false,"module_vendor_integration_sandbox":false,"module_flag_google_analytics_v4":false,"module_mapping_clientbook_associates":true,"on_all_stores_mapping_clientbook_associates":true,"module_rental_auto_reminder_on":false,"module_posthog_tracking":false,"module_fix_order_note_for_sub_and_rental_payments":true,"on_all_stores_fix_order_note_for_sub_and_rental_payments":true,"module_adyen_accounts_per_location":false,"module_assemble_disassemble":false,"module_system_callout_for_reports":false,"module_lock_transaction_save":true,"on_all_stores_lock_transaction_save":true,"module_custom_labels_templates_in_print_modal":false,"module_open_ai_long_description":true,"on_all_stores_open_ai_long_description":true,"module_po_export_fix_comma":false,"module_fix_signup_disappear_after_customer_added_register":false,"module_avalara_tax_code_issue":false,"module_inventory_history_fix_other_event_when_sn_removed":true,"on_all_stores_inventory_history_fix_other_event_when_sn_removed":true,"module_item_filters_dollar_off_coupons":false,"module_flag_add_external_migration_id_to_migration_cleanup":true,"on_all_stores_flag_add_external_migration_id_to_migration_cleanup":true,"module_flag_set_date_received_from_new_product_upload":true,"on_all_stores_flag_set_date_received_from_new_product_upload":true,"module_prevent_close_on_print":false,"module_rto_autopay_improvements_issue_indicator":false,"module_handle_serialized_line_item_upload_migrated_option_id":true,"on_all_stores_handle_serialized_line_item_upload_migrated_option_id":true,"module_stripe_send_level_3_data":true,"on_all_stores_stripe_send_level_3_data":true,"module_fix_previous_payments_for_multiple_contracts":true,"on_all_stores_fix_previous_payments_for_multiple_contracts":true,"module_locations_in_scheduled_sale":false,"module_fix_send_to_list_validation_schedule_email":false,"module_toggle_product_page_version":true,"on_all_stores_toggle_product_page_version":true,"module_allow_super_admin_download_ext_customer_id":false,"module_flag_add_migrated_customer_to_cleanup_tool":true,"on_all_stores_flag_add_migrated_customer_to_cleanup_tool":true,"module_show_adyen_fire_message":false,"module_smaller_pslr_status_updates":true,"on_all_stores_smaller_pslr_status_updates":true,"module_add_customer_id_type_transaction_upload":true,"on_all_stores_add_customer_id_type_transaction_upload":true,"module_send_mix_panel_event_on_zipcode_change_web_checkout":false,"module_locally_push2cart_integration":false,"module_beta_features_feedback":true,"on_all_stores_beta_features_feedback":true,"module_quick_assemble":false,"module_verify_payment_id":true,"on_all_stores_verify_payment_id":true,"module_email_verification":false,"module_layaway_migration":false,"module_send_mixpanel_event_on_mms_customer_disconnect":false,"module_improved_waitlist":true,"on_all_stores_improved_waitlist":true,"module_use_amex_pricing":true,"on_all_stores_use_amex_pricing":true,"module_additional_settings_custom_tenders":true,"on_all_stores_additional_settings_custom_tenders":true,"module_nps_page_v2":true,"on_all_stores_nps_page_v2":true,"module_extend_email_view_page":false,"module_set_store_id_for_transaction_if_has_value":false,"module_deprecate_on_account":true,"on_all_stores_deprecate_on_account":true,"module_restricted_login":false,"module_eod_summary_v2":true,"on_all_stores_eod_summary_v2":true,"module_enhanced_interrogation_techniques":true,"module_work_orders_current_store_location_id":true,"on_all_stores_work_orders_current_store_location_id":true,"module_prevent_utf8_in_header_columns":true,"on_all_stores_prevent_utf8_in_header_columns":true,"module_gia_sandbox":false,"module_edit_appraisals":true,"on_all_stores_edit_appraisals":true,"module_fix_edit_appraisal_template":true,"on_all_stores_fix_edit_appraisal_template":true,"module_slack_notification_when_store_connects_clientbook":true,"on_all_stores_slack_notification_when_store_connects_clientbook":true,"module_fix_image_upload_invalid_extension":false,"module_show_warning_if_no_price_for_new_consignment_items":false,"module_fix_sorting_by_technician_in_wo":true,"on_all_stores_fix_sorting_by_technician_in_wo":true,"module_store_type_color_scheme":true,"on_all_stores_store_type_color_scheme":true,"module_fix_deleting_main_image_from_all_products":true,"on_all_stores_fix_deleting_main_image_from_all_products":true,"module_respect_classes_setting_in_all_places":true,"on_all_stores_respect_classes_setting_in_all_places":true,"module_markup_pricing_flag":true,"on_all_stores_markup_pricing_flag":true,"module_image_inventory_velocity_report":true,"on_all_stores_image_inventory_velocity_report":true,"module_gia_slack_logging":false,"module_category_issue_new_pp":true,"on_all_stores_category_issue_new_pp":true,"module_risky_recipients_tool":false,"module_fix_wo_tags":true,"on_all_stores_fix_wo_tags":true,"module_beta_product_feedback_report":true,"on_all_stores_beta_product_feedback_report":true,"module_check_duplication_upc_mfr_id":true,"on_all_stores_check_duplication_upc_mfr_id":true,"module_product_page_fix_tax_clearing":true,"on_all_stores_product_page_fix_tax_clearing":true,"module_nps_report_list_update":true,"on_all_stores_nps_report_list_update":true,"module_custom_zpl_tools":false,"module_print_note_wo_items":true,"on_all_stores_print_note_wo_items":true,"module_facet_fields_order_web_fix":true,"on_all_stores_facet_fields_order_web_fix":true,"module_po_clear_date_issue":true,"on_all_stores_po_clear_date_issue":true,"module_email_cleanup_script_banner":false,"module_unsaved_inventory_warnings":false,"module_fix_appraisal_item_on_close":true,"on_all_stores_fix_appraisal_item_on_close":true,"module_404_on_bogus_category_url":true,"on_all_stores_404_on_bogus_category_url":true,"module_fix_backspace_till_card_payment":true,"on_all_stores_fix_backspace_till_card_payment":true,"module_beta_feedback_to_use_index_db":true,"on_all_stores_beta_feedback_to_use_index_db":true,"module_setting_for_default_website_sorting_option":true,"on_all_stores_setting_for_default_website_sorting_option":true,"module_marketplaces_slowdown_fix":true,"on_all_stores_marketplaces_slowdown_fix":true,"module_slack_notification_when_store_disconnects_clientbook":true,"on_all_stores_slack_notification_when_store_disconnects_clientbook":true,"module_confirm_opt_in_email":true,"on_all_stores_confirm_opt_in_email":true,"module_suggest_feature_modal_email_fix":true,"on_all_stores_suggest_feature_modal_email_fix":true,"module_better_coupons":false,"module_fix_saving_variant_pictures_on_npp":true,"on_all_stores_fix_saving_variant_pictures_on_npp":true,"module_edit_component_vue":true,"module_generate_seo":true,"on_all_stores_generate_seo":true,"module_show_prop_65_warning_setting":true,"on_all_stores_show_prop_65_warning_setting":true,"module_line_totals_add_invoice_payment_and_store_credit":true,"on_all_stores_line_totals_add_invoice_payment_and_store_credit":true,"module_manage_301_redirects":true,"on_all_stores_manage_301_redirects":true,"module_layaway_remaining_balance_fix":true,"on_all_stores_layaway_remaining_balance_fix":true,"module_apply_all_reward_coupons_fix":true,"on_all_stores_apply_all_reward_coupons_fix":true,"module_fix_shipping_method_dropdown_in_orders_module":false,"module_mms_payment_warning_flag":false,"module_increase_default_image_size_wo_form_style":true,"on_all_stores_increase_default_image_size_wo_form_style":true,"module_fix_pslr_images":true,"on_all_stores_fix_pslr_images":true,"module_barcode_printing_location_issue":true,"on_all_stores_barcode_printing_location_issue":true,"module_refactoring_getting_piis_for_inventory_tab_on_npp":false,"module_inventory_summary_modal":true,"on_all_stores_inventory_summary_modal":true,"module_omnichannel_respect_data_source":true,"on_all_stores_omnichannel_respect_data_source":true,"module_luxsurance_sandbox":false,"module_luxsurance_functionality":false,"module_luxsurance_logging_in_slack":false,"module_fix_locked_rental_payment":false,"module_speed_up_locally_sync":true,"on_all_stores_speed_up_locally_sync":true,"module_Jewelers_for_children_slack_logging":true,"on_all_stores_Jewelers_for_children_slack_logging":true,"module_so_care_plan_zero_payment_issue":true,"on_all_stores_so_care_plan_zero_payment_issue":true,"module_care_plans_sale_price_issue":true,"on_all_stores_care_plans_sale_price_issue":true,"module_fix_product_page_width_issue":true,"on_all_stores_fix_product_page_width_issue":true,"module_web_link_text_editor_issue":true,"on_all_stores_web_link_text_editor_issue":true,"module_fix_rto_loading_due_to_cookie":true,"on_all_stores_fix_rto_loading_due_to_cookie":true,"module_fix_rental_account_statement_past_dues":false,"module_fix_barcode_location_modal":true,"on_all_stores_fix_barcode_location_modal":true,"module_product_placeholder_flag":true,"on_all_stores_product_placeholder_flag":true,"module_print_before_save_from_opp_modal":true,"on_all_stores_print_before_save_from_opp_modal":true,"module_ro_duplicate_barcodes_fix":true,"on_all_stores_ro_duplicate_barcodes_fix":true,"module_save_luxsurance_insurance_info_after_reloading":false,"module_initial_save_for_new_product_on_the_old_product_page":true,"on_all_stores_initial_save_for_new_product_on_the_old_product_page":true,"module_increase_image_size_wo_print":true,"on_all_stores_increase_image_size_wo_print":true,"module_reorder_components":true,"on_all_stores_reorder_components":true,"module_remove_business_name_on_receipts":false,"module_handle_interac_with_adyen":true,"on_all_stores_handle_interac_with_adyen":true,"module_bnb_tmp_files":true,"on_all_stores_bnb_tmp_files":true,"module_user_timeout":true,"on_all_stores_user_timeout":true,"module_set_default_printer_to_barcode_printer_modal":true,"on_all_stores_set_default_printer_to_barcode_printer_modal":true,"module_unsubscribes_feature_flag":true,"on_all_stores_unsubscribes_feature_flag":true,"module_fix_product_dimensions":true,"on_all_stores_fix_product_dimensions":true,"module_markup_pricing_send_mixpanel_event":true,"on_all_stores_markup_pricing_send_mixpanel_event":true,"module_ro-ai-upload":true,"on_all_stores_ro-ai-upload":true,"module_stones_facets":true,"on_all_stores_stones_facets":true,"module_show_subaccount_status":true,"on_all_stores_show_subaccount_status":true,"module_so_fix_remaining_balance":true,"on_all_stores_so_fix_remaining_balance":true,"module_restore_school_delivery_shipping_option":false,"module_log_everything_sent_to_luxsurance":false,"module_kinder_return_growl_message":true,"on_all_stores_kinder_return_growl_message":true,"module_transfer_permissions":true,"on_all_stores_transfer_permissions":true,"module_fix_opening_product_page_from_website_categories":true,"on_all_stores_fix_opening_product_page_from_website_categories":true,"module_hide_jewelers_for_children_notifications_from_store_with_stripe":true,"on_all_stores_hide_jewelers_for_children_notifications_from_store_with_stripe":true,"module_product_page_builder":true,"on_all_stores_product_page_builder":true,"module_show_bin_location_ids":true,"on_all_stores_show_bin_location_ids":true,"module_work_order_custom_signature":true,"on_all_stores_work_order_custom_signature":true,"module_refactoring_wo_settings_tab":true,"on_all_stores_refactoring_wo_settings_tab":true,"module_stone_custom_label":true,"on_all_stores_stone_custom_label":true,"module_query_builder_for_so":true,"on_all_stores_query_builder_for_so":true,"module_fix_upload_image_by_upc_mfr_id":true,"on_all_stores_fix_upload_image_by_upc_mfr_id":true,"module_add_bin_location_column_spreadsheet":true,"on_all_stores_add_bin_location_column_spreadsheet":true,"module_saving_loose_stone_from_catalog":true,"on_all_stores_saving_loose_stone_from_catalog":true,"module_fix_scheduled_sale_does_not_delete_original_prices":true,"on_all_stores_fix_scheduled_sale_does_not_delete_original_prices":true,"module_adyen_send_level_3_data":true,"on_all_stores_adyen_send_level_3_data":true,"module_fix_ro_condition_inventory":true,"on_all_stores_fix_ro_condition_inventory":true,"module_blue_book_flag":false,"module_upload_fix_pslr_without_product_id":true,"on_all_stores_upload_fix_pslr_without_product_id":true,"module_edit_stone_details_spreadsheet":true,"on_all_stores_edit_stone_details_spreadsheet":true,"module_vendor_markup_flag":true,"on_all_stores_vendor_markup_flag":true,"module_searching_only_stone_for_loose_stone":false,"module_fix_images_old_new_product_page":true,"on_all_stores_fix_images_old_new_product_page":true,"module_rto_import_add_next_payment_date_column":true,"on_all_stores_rto_import_add_next_payment_date_column":true,"module_customer_primary_location":false,"module_loose_stone_in_po_ro":true,"on_all_stores_loose_stone_in_po_ro":true,"module_large_images_in_reg":true,"on_all_stores_large_images_in_reg":true,"module_bad_emails":true,"module_validate_imported_rto_payment_amount_with_interest":true,"on_all_stores_validate_imported_rto_payment_amount_with_interest":true,"module_expand_collapse_web_filters":true,"on_all_stores_expand_collapse_web_filters":true,"module_fix_bootstrap_switch_circle":true,"on_all_stores_fix_bootstrap_switch_circle":true,"module_bin_location_bulk_messaging":false,"module_fix_ecomm_canada_tax":true,"on_all_stores_fix_ecomm_canada_tax":true,"module_fix_inventory_save_new_product_page":true,"on_all_stores_fix_inventory_save_new_product_page":true,"module_add_serial_number_to_wo_custom_message":true,"on_all_stores_add_serial_number_to_wo_custom_message":true,"module_sales_details_report_integration_filter":true,"on_all_stores_sales_details_report_integration_filter":true,"module_fix_invoice_online_line_item_summary":true,"on_all_stores_fix_invoice_online_line_item_summary":true,"module_add_stripe_to_payment_success_worker":true,"on_all_stores_add_stripe_to_payment_success_worker":true,"module_update_to_captcha_v3":false,"module_adyen_send_level_3_data_auth_capture":true,"on_all_stores_adyen_send_level_3_data_auth_capture":true,"module_copy_super_user":true,"on_all_stores_copy_super_user":true,"module_remove_domain_spaces":false,"module_report_permissions":false,"module_metal_pricing":false,"module_service_shadow_rows_wo":false,"module_fix_empty_bin_location_spreadsheet":true,"on_all_stores_fix_empty_bin_location_spreadsheet":true,"module_adjust_shopify_unlimited_logic":false,"module_metal_pricing_error_slack_logging":false,"module_metal_pricing_log_everything_sent":false,"module_metal_pricing_sandbox":false,"module_featured_features_v2":true,"on_all_stores_featured_features_v2":true,"module_fix_worker_order_wont_print_null_target_date":true,"on_all_stores_fix_worker_order_wont_print_null_target_date":true,"module_disable_express_checkout":false,"module_allow_phone_email_manual_card_entry":true,"on_all_stores_allow_phone_email_manual_card_entry":true,"module_fix_appraisal_print_preview_displaying":true,"on_all_stores_fix_appraisal_print_preview_displaying":true,"module_address_export_fields":true,"on_all_stores_address_export_fields":true,"module_new_pp_optimize":true,"on_all_stores_new_pp_optimize":true,"module_care_plans_in_special_orders":true,"on_all_stores_care_plans_in_special_orders":true,"module_avs_ecommerce":true,"on_all_stores_avs_ecommerce":true,"module_wo_claim_ticket_till_fix":true,"on_all_stores_wo_claim_ticket_till_fix":true,"module_wo_rename_add_to_register_button":true,"on_all_stores_wo_rename_add_to_register_button":true,"module_default_class_page_v2":true,"on_all_stores_default_class_page_v2":true,"module_alert_print_ro_custom_template_no_vendor":true,"on_all_stores_alert_print_ro_custom_template_no_vendor":true,"module_fix_gtag_purchase_event_vars":true,"on_all_stores_fix_gtag_purchase_event_vars":true,"module_move_web_inventory_setting_from_admin_settings_to_store_settings":true,"on_all_stores_move_web_inventory_setting_from_admin_settings_to_store_settings":true,"module_allow_no_sn_in_loose_stone":true,"on_all_stores_allow_no_sn_in_loose_stone":true,"module_fix_saving_loose_stone_inventory":true,"on_all_stores_fix_saving_loose_stone_inventory":true,"module_po_upload_files_ai":false,"module_delayed_mixpanel_event":true,"on_all_stores_delayed_mixpanel_event":true,"module_website_page_code":true,"on_all_stores_website_page_code":true,"module_stop_serialized_switching_old_pp":true,"on_all_stores_stop_serialized_switching_old_pp":true,"module_product_table_view":true,"on_all_stores_product_table_view":true,"module_gmroi_in_inventory_age":true,"on_all_stores_gmroi_in_inventory_age":true,"module_material_fix_class_v2":true,"on_all_stores_material_fix_class_v2":true,"module_sales_tax_ignore_transaction_level_discounts":false,"module_parafin_ad":false,"module_reorder_non_responsive_fix":false,"module_respect_custom_tenders_order_in_tenders_by_till":true,"on_all_stores_respect_custom_tenders_order_in_tenders_by_till":true,"module_date_range_filter_for_aging_report":true,"on_all_stores_date_range_filter_for_aging_report":true,"module_default_sales_representative":true,"on_all_stores_default_sales_representative":true,"module_add_flat_rate_to_consignor":true,"on_all_stores_add_flat_rate_to_consignor":true,"module_parafin_sandbox":false,"module_po_ro_open_created_product_new_pp":true,"on_all_stores_po_ro_open_created_product_new_pp":true,"module_rental_contracts_paypal_method":false,"module_rto_ecom_tab_rrr":false,"module_update_quantity_instead_of_new_line_in_till":true,"on_all_stores_update_quantity_instead_of_new_line_in_till":true,"module_independent_scrolling_on_web":false,"module_upc_and_sku_for_work_orders":true,"on_all_stores_upc_and_sku_for_work_orders":true,"module_log_transaction_without_store_id":true,"on_all_stores_log_transaction_without_store_id":true,"module_search_in_department_in_wo":true,"on_all_stores_search_in_department_in_wo":true,"module_donations_report":true,"on_all_stores_donations_report":true,"module_batch_inventory_alternate_lookup":true,"on_all_stores_batch_inventory_alternate_lookup":true,"module_geller_blue_book_work_order":false,"module_fix_wo_take_deposit_redirect":true,"on_all_stores_fix_wo_take_deposit_redirect":true,"module_bug_so_bin_location":true,"on_all_stores_bug_so_bin_location":true,"module_item_title_hyperlink":true,"on_all_stores_item_title_hyperlink":true,"module_stop_deleting_resumed_transactions":true,"on_all_stores_stop_deleting_resumed_transactions":true,"module_start_date_in_rental_contracts":true,"on_all_stores_start_date_in_rental_contracts":true,"module_tag_in_work_order_list":true,"on_all_stores_tag_in_work_order_list":true,"module_fix_wo_search_numeric":true,"on_all_stores_fix_wo_search_numeric":true,"module_package_coupons":false,"module_website_page_code_template_fix":true,"on_all_stores_website_page_code_template_fix":true,"module_fix_no_tax_profile_rto_import_blank_tax_profile":true,"on_all_stores_fix_no_tax_profile_rto_import_blank_tax_profile":true,"module_shopify_partial_refund_flag":true,"on_all_stores_shopify_partial_refund_flag":true,"module_pc_dupe_fix":true,"on_all_stores_pc_dupe_fix":true,"module_scrap_metal_flag":false,"module_generate_sku_for_work_order":true,"on_all_stores_generate_sku_for_work_order":true,"module_no_tag_wo_filter":true,"on_all_stores_no_tag_wo_filter":true,"module_product_list_v2":false,"module_text_communication":true,"on_all_stores_text_communication":true,"module_store_name_in_flag_queries":true,"on_all_stores_store_name_in_flag_queries":true,"module_worker_for_cleaning_unavailable_items":false,"module_delete_consignment_items_with_history_event":true,"on_all_stores_delete_consignment_items_with_history_event":true,"module_debug_errors_for_marketing_email_manager":true,"on_all_stores_debug_errors_for_marketing_email_manager":true,"module_add_loaner_section_in_work_order_modal":true,"on_all_stores_add_loaner_section_in_work_order_modal":true,"module_sp_not_appear_in_purchase_queue":true,"on_all_stores_sp_not_appear_in_purchase_queue":true,"module_work_order_completion_date":true,"on_all_stores_work_order_completion_date":true,"module_show_in_store_pickup_without_zip":false,"module_fix_suspended_transaction_showing_wrong_total":true,"on_all_stores_fix_suspended_transaction_showing_wrong_total":true,"module_reset_tax_profile_dropbox_after_select_customer":true,"on_all_stores_reset_tax_profile_dropbox_after_select_customer":true,"module_show_managed_chargeback_payout_report":true,"on_all_stores_show_managed_chargeback_payout_report":true,"module_stone_mixpanel":false,"module_common_website_js":true,"on_all_stores_common_website_js":true,"module_paused_transaction_selling_duplicate_sn":true,"on_all_stores_paused_transaction_selling_duplicate_sn":true,"module_ship_to_school_for_non_rto_or_osr":true,"on_all_stores_ship_to_school_for_non_rto_or_osr":true,"module_fix_repair_item_service_and_material_import":true,"on_all_stores_fix_repair_item_service_and_material_import":true,"module_fix_so_multiple_deposit_negative_balance":true,"on_all_stores_fix_so_multiple_deposit_negative_balance":true,"module_outstanding_invoice_print_display_incorrect_amount":true,"on_all_stores_outstanding_invoice_print_display_incorrect_amount":true,"module_fix_geller_prices":false,"module_fix_serial_number_in_wo_item":true,"on_all_stores_fix_serial_number_in_wo_item":true,"module_add_submit_workorder_online_feature":false,"module_fix_reverb_sku_issue":true,"on_all_stores_fix_reverb_sku_issue":true,"module_created_date_po_ro":true,"on_all_stores_created_date_po_ro":true,"module_fix_filter_customers_not_working_with_class":true,"on_all_stores_fix_filter_customers_not_working_with_class":true,"module_fix_layaway_negative_item_quantity":true,"on_all_stores_fix_layaway_negative_item_quantity":true,"module_waitlist_past_classes_view":true,"on_all_stores_waitlist_past_classes_view":true,"module_show_aim_data_in_customer_account":false,"module_reorder_point_on_new_product_view":true,"on_all_stores_reorder_point_on_new_product_view":true,"module_inventory_is_displaying_double_quantity":true,"on_all_stores_inventory_is_displaying_double_quantity":true,"module_save_numbers_for_sent_newsletters":true,"on_all_stores_save_numbers_for_sent_newsletters":true,"module_fix_voiding_layaway_payments_not_updating_layaway_balance":true,"on_all_stores_fix_voiding_layaway_payments_not_updating_layaway_balance":true,"module_blog_module":false,"module_old_global_css_fix":true,"on_all_stores_old_global_css_fix":true,"module_oi_report_location_fix":false,"module_respect_customer_discount_status_for_web_transactions":true,"on_all_stores_respect_customer_discount_status_for_web_transactions":true,"module_osr_make_required_box_respect_check_option":true,"on_all_stores_osr_make_required_box_respect_check_option":true,"module_remaining_balance_gift_card":true,"on_all_stores_remaining_balance_gift_card":true,"module_fix_trade_in_credit_in_returns":true,"on_all_stores_fix_trade_in_credit_in_returns":true,"module_subscription_status_missing_or_wrong":true,"on_all_stores_subscription_status_missing_or_wrong":true,"module_remove_so_date_picked_up_map":true,"on_all_stores_remove_so_date_picked_up_map":true,"module_fix_vendor_column_memo":true,"on_all_stores_fix_vendor_column_memo":true,"module_rto_online_ignore_fixed_rate":true,"on_all_stores_rto_online_ignore_fixed_rate":true,"module_fix_layaway_scheduled_payments":false,"module_add_dashboard_link_to_stripe_stores":true,"on_all_stores_add_dashboard_link_to_stripe_stores":true,"module_shipstation_verbiage":true,"on_all_stores_shipstation_verbiage":true,"module_module_custom_classes":true,"on_all_stores_module_custom_classes":true,"module_sale_consignment_items_of_the_same_type":true,"on_all_stores_sale_consignment_items_of_the_same_type":true,"module_more_subscription_issues":true,"on_all_stores_more_subscription_issues":true,"module_comparison_report":false,"module_newsletters_numbers_refactoring":true,"on_all_stores_newsletters_numbers_refactoring":true,"module_signature_optional_in_receipt_form_style":true,"on_all_stores_signature_optional_in_receipt_form_style":true,"module_fix_receipt_product_total_price":true,"on_all_stores_fix_receipt_product_total_price":true,"module_remove_show_default_footer_setting":true,"on_all_stores_remove_show_default_footer_setting":true,"module_auto_populate_vendor_from_catalog":true,"on_all_stores_auto_populate_vendor_from_catalog":true,"module_sales_details_report_product_modal":true,"on_all_stores_sales_details_report_product_modal":true,"module_remove_product_duplicate":true,"on_all_stores_remove_product_duplicate":true,"module_fix_customer_with_layaways_discount":false,"module_display_on_hand_in_product_item_and_search":true,"on_all_stores_display_on_hand_in_product_item_and_search":true,"module_rto_search_products_only":true,"on_all_stores_rto_search_products_only":true,"module_so_product_create_add":true,"on_all_stores_so_product_create_add":true,"module_copy_site_css":true,"on_all_stores_copy_site_css":true,"module_receipt_options_modal_redesign":false,"module_add_layaway_tab_on_customer_profile":true,"on_all_stores_add_layaway_tab_on_customer_profile":true,"module_cannot_capture_order_less_than_authorized":true,"on_all_stores_cannot_capture_order_less_than_authorized":true,"module_fix_default_assigned_vendor_in_so":true,"on_all_stores_fix_default_assigned_vendor_in_so":true,"module_allow_users_to_edit_product_in_till":false,"module_print_on_all_pages_in_form_style":false,"module_shopify_proportional_partial_refund":false,"module_wo_any_status_to_sale":false,"module_wo_incorrect_insufficient_qty":true,"on_all_stores_wo_incorrect_insufficient_qty":true,"module_fix_extra_rto_charged_amount":false,"module_add_tax_id_company_name_columns_to_sales_details_report":true,"on_all_stores_add_tax_id_company_name_columns_to_sales_details_report":true,"module_wo_reopen_warning":true,"on_all_stores_wo_reopen_warning":true,"module_fix_stripe_metadata_for_rto":true,"on_all_stores_fix_stripe_metadata_for_rto":true,"module_wo_template_tax":true,"on_all_stores_wo_template_tax":true,"module_hide_live_selling":true,"on_all_stores_hide_live_selling":true,"module_rc_template_payment_day_fix":true,"on_all_stores_rc_template_payment_day_fix":true,"module_inventory_report_refactoring":false,"module_inventory_history_show_sku_column":true,"on_all_stores_inventory_history_show_sku_column":true,"module_payment_plan_due_date_calendar":true,"on_all_stores_payment_plan_due_date_calendar":true,"module_edit_content_global_css":true,"on_all_stores_edit_content_global_css":true,"module_order_card_type":true,"on_all_stores_order_card_type":true,"module_subscription_status_fixes_flag":false,"module_product_bin_location_filter":false,"module_fix_utf_response_issue":false,"module_toggle_disable_domain_expiration_notification":false,"module_increase_wo_modal_width":false,"module_product_metal_info":false,"module_prevent_shipping_pitr_duplication":false,"module_layaway_customer_actions_adjustments":false,"module_sales_detail_report_on_hand_column":false,"module_include_wo_and_so_balances_in_balance_owed_field":false,"module_fix_wo_receipt_formatting":false,"module_packrat_extended_product_pslr_for_product_list_page_v2":false,"module_social_media_manager":false,"module_shipstation_error_fix":false,"module_quote_escape_fix":false,"module_add_discounted_payoffs_to_rto":false,"module_job_condition_field_for_work_order":false,"module_wo_fields_configuration":false,"module_wo_receipt_hide_item_details":false,"module_validate_min_price_for_care_plans":false,"module_unsubscribe_from_email_failing":false,"module_in_classes_not_able_to_add_required_material":false,"module_invoice":true,"module_wos":false,"module_shopify":false,"module_ebay":false,"use_receptive":true,"wholesale_shipping":true,"locally":false,"website_customer_login":true,"captcha_at_checkout":true,"web_allow_discount_stacking":true,"website_pricing":false,"module_out_of_stock_product_card":true,"three_decimal_pricing":false,"displayReportsImagesByDefault":false,"pos_customer_rewards":true,"pos_shift_management":false,"pos_enable_tax_inclusive_pricing":false,"pos_show_tax_breakdown_on_receipt":false,"product_module_item_conditions":false,"product_module_dont_use_item_conditions_online":false,"pos_allow_discount_stacking":true,"printDescriptionOnReceipt":false,"WishlistEnabled":false,"is_responsive":true,"module_show_sku_till_product_search":true,"module_docraptor_test_mode":false,"module_rental_location_tax_integration":false}');
    var industryTerms = {"vendor_consignment":"Vendor Consignment","vendor_consign":"Vendor Consign","vendor_consignment_short":"VC","consignment":"Consignment","consignment_short":"C"};
</script>
<script>
    window.CheckoutUrl = 'checkout/cart.php';
    window.EditCartUrl = 'checkout/cart.php';
    window.cartArray = [];
    window.cartJWT = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTI0NjA3MjMsImp0aSI6IjYzOTkxZGY3ZGI5OGUwZTVjNmZjMWQ2NDJhY2QyZDFlNTQwZjU2YTQ2MmJkYmUzODczYTkzZDE0ZGFmMWRmODIiLCJuYmYiOjE3NTI0NjA3MjMsImV4cCI6MTc1MjUwMzkyMywiZGF0YSI6eyJzdG9yZUlkIjo3MzgxfX0.UK_e_lZBEYgMIP8m0WHbqkdR1_YAU7Z40-_kfKw7ZLY';
</script>
<script src="/1723204579/js/bower_components/vue/axios.0.18.0.min.js"></script>
<script src="/1723204579/pos-app/js/big.min.js"></script>
<script src="/1723204579/pos-app/js/lib.js"></script>
<script src="/1748457328/c/cart/cart.js"></script>
<script>$(function() { setCartUuidCookie('30DECAAB-82D6-C4EC-203B-E0D2D2DB29C8'); }); // do-not-cache-this-line Do not remove this comment</script>
<script src='https://cdnjs.cloudflare.com/polyfill/v3/polyfill.min.js?features=Promise'></script>
<script>
            window.cartLoading = false;
            window.cartLoaded = false;
            window.cartLoadError = null;

            window.getDataWithDelay = function(callback) {
                var timeToWaitForLoadData = 100;

                window.localStorage.removeItem('loading-interrupted');

                return new Promise(function(resolve, reject) {
                    setTimeout(function () {
                        resolve(callback());
                    }, timeToWaitForLoadData);
                });
            };

            window.isCarePlanEnable = function() {
                return window.knobby && window.knobby.module_care_plans;
            };

            function LoadCart(event) {
                if (window.cartLoading || window.cartLoaded) {
                    return;
                }

                window.cartLoadError = null;
                window.cartLoading = true;

                var myAxios = getAxiosInstance();
                var cartUuid = getCartUuidFromCookie();

                if (cartUuid) {
                    var requestCard = function() {
                        return myAxios.get('/api/cart/data/' + cartUuid);
                    };

                    if (window.isCarePlanEnable() && window.localStorage.getItem('loading-interrupted')) {
                        requestCard = function() {
                            return window.getDataWithDelay(function() {
                                return myAxios.get('/api/cart/data/' + cartUuid);
                            });
                        };
                    }

                    requestCard().then(function(response) {
                        var cartData = response && response.data && response.data.data ? response.data.data : '';

                        CreateCartArray(cartData);
                        ShowCart(false);

                        window.cartLoaded = true;
                        window.cartLoading = false;
                    }).catch(function (e) {
                        window.cartLoading = false;
                        window.cartLoadError = e;

                        throw e;
                    });
                } else {
                    CreateCartArray('');
                    ShowCart(false);

                    window.cartLoaded = true;
                    window.cartLoading = false;
                }
            }

            function LoadCartAsync() {
                LoadCart();

                return new Promise(function(resolve, reject) {
                    const timerId = setInterval(function(resolve, reject) {
                        if (window.cartLoading) {
                            return;
                        }

                        clearInterval(timerId);

                        if (window.cartLoaded) {
                            resolve();
                        } else {
                            reject(window.cartLoadError || new Error('Cart was not loaded'));
                        }
                    }, 100, resolve, reject);
                });
            }

            window.onpageshow = function(event){
                if(event.persisted){
                    window.location = window.location;
                }else{
                    LoadCart();
                }
            }
            window.onpopstate = LoadCart;
            window.onload = LoadCart;
        </script>
<script type="text/javascript" src="/1736167064/pos-app/js/model/WaitList.js"></script>
<script>
                function innerWrapper() {
                    const innerDivz = document.querySelectorAll(`div.inner`);
                    if (innerDivz.length > 0) {
                        const wrapperEl = document.createElement('div');
                        wrapperEl.className = 'new container clearfix';
                        innerDivz[0].insertAdjacentElement('beforebegin', wrapperEl);
                        innerDivz.forEach(item => wrapperEl.append(item));
                    }
                }
                document.addEventListener('DOMContentLoaded', innerWrapper);
            </script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  // 1) only on /c/account pages
  if (!location.pathname.includes('/c/account')) return;
  var footer = document.querySelector('div.container.footer');
  if (!footer) return;

  // 2) kill any <br> so the links can live on one line
  footer.querySelectorAll('br').forEach(br => br.remove());

  // 3) inject a <style> that unifies normal + hover rules under 798px
  var css = `
   
      
      .container.footer > a.footer,
      .container.footer > a.footer:hover {
        display: inline-block      !important;
        margin: 0 0.5rem           !important; /* tweak this gap to taste */
        vertical-align: middle     !important;
        font-family: 'Figtree', sans-serif !important;
        text-transform: uppercase  !important;
        font-weight: 600           !important;
        font-size: 1em             !important;
        color: #D54D52             !important;
        text-decoration: underline !important;
      }
    }
.bgFooter {
  background: transparent !important; /* REMOVE wood texture from the footer */
  padding: 2rem 0;
  display: flex;
  justify-content: center;
}
  `;
  var s = document.createElement('style');
  s.appendChild(document.createTextNode(css));
  document.head.appendChild(s);
});
</script>
<script>

setInterval(() => {
  const slider = document.querySelector('.slider-container');
  if (slider && slider.style.display !== 'none') {
    slider.style.display = 'none';
  }
}, 100);


// Set these manually ()
window.minFilterPrice = 0;
window.maxFilterPrice = 1000; // ? update this manually if needed

const cleanUpSlider = setInterval(() => {
  const minInput = document.querySelector('.input-min');
  const maxInput = document.querySelector('.input-max');
  const slider = document.querySelector('.slider-container');

  if (minInput && maxInput) {
    clearInterval(cleanUpSlider);

    // Remove slider visually
    if (slider) slider.style.display = 'none';

    // Update placeholders
    minInput.placeholder = 'Minimum price';
    maxInput.placeholder = 'Maximum price';

    // Allow typing, but limit max
    maxInput.addEventListener('input', () => {
      const value = parseFloat(maxInput.value);
      if (value > 1000) maxInput.value = '1000';
    });
  }
}, 300);
</script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll('#product-list-wrapper .product-item');
  items.forEach(item => {
    item.style.visibility = 'visible';
  });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  // locate the “Sew Days” <li> by its link text
  var items = document.querySelectorAll('#navbar-collapse-1 .dropdown-menu > li'),
      sewLi = Array.from(items).find(li => {
        var a = li.querySelector('a');
        return a && a.textContent.trim() === 'Sew Days';
      });
  if(!sewLi) return;

  // mark it as a nested dropdown
  sewLi.classList.add('dropdown','dropdown-submenu');

  // upgrade its <a> into a clean toggle
  var sewA = sewLi.querySelector('a');

  // REMOVE Bootstrap’s automatic dropdown behavior:
  sewA.removeAttribute('data-toggle');
  // (you can also drop its 'dropdown-toggle' class if you like)
  // sewA.classList.remove('dropdown-toggle');

  // ensure it doesn’t navigate anywhere
  sewA.setAttribute('href','#');
  sewA.setAttribute('role','button');
  sewA.setAttribute('aria-expanded','false');
  sewA.style.cursor = 'pointer';

  // build the inner submenu items
  var sub = document.createElement('ul');
  sub.className = 'dropdown-menu';
  sub.setAttribute('role','menu');
  [
    ['Saturday Sew Day',        'https://www.boxcarquilts.com/module/class/577942/2025-saturday-sew-day'],
    ['Sit & Stitch Social',     'https://www.boxcarquilts.com/module/class/501837/sit-and-stitch-social'],
    ['Saturday Stitchery',      'https://www.boxcarquilts.com/module/class/604673/saturday-stitchery']
  ].forEach(([txt, href])=>{
    var li = document.createElement('li'),
        a  = document.createElement('a');
    a.textContent = txt;
    a.href        = href;
    li.appendChild(a);
    sub.appendChild(li);
  });
  sewLi.appendChild(sub);

  // THIS is the only click handler on that link:
  sewA.addEventListener('click', function(e){
    e.preventDefault();      // no navigation
    e.stopPropagation();     // don’t let Bootstrap or your collapse toggle see this click
    sewLi.classList.toggle('open');
  });
});
</script>
<script type="text/javascript" src="/js/libs/vue/2.6.12.vue.min.js"></script>
<script type="text/javascript" src="/js/libs/axios/0.27.2.axios.min.js"></script>
<script type="text/javascript" src="/js/dist/npm.core-js.a1c15addf2ce935a1f7b.js"></script>
<script type="text/javascript" src="/js/dist/npm.vue-loader.86f95d32df03c9bf054e.js"></script>
<script type="text/javascript" src="/js/dist/npm.style-loader.53da627498d619967689.js"></script>
<script type="text/javascript" src="/js/dist/npm.css-loader.cc4d737372494bc04f65.js"></script>
<script type="text/javascript" src="/js/dist/npm.date-fns.40eb527a4fe2a38e4c93.js"></script>
<script type="text/javascript" src="/js/dist/npm.uuid.94255209536a39261fd8.js"></script>
<script type="text/javascript" src="/js/dist/website-components.b8facec53a47a159cb87.js"></script>

<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"d60c52fc57","applicationID":"7339757","transactionName":"ZAFTMEcHDUsDB00IDl1LZBZcSQAXAwdaDhRdEB4IWgEKVkwUURE=","queueTime":0,"applicationTime":89,"atts":"SEZQRg8dHkU=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>